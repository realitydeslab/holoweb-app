/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
/**
 * Tracks property overrides and restores them in reverse order.
 *
 * A failed patch is never recorded, so callers can safely try an instance
 * first and then fall back to its prototype.
 */
export declare class PatchRegistry {
    private entries;
    get size(): number;
    define(target: object, key: PropertyKey, descriptor: PropertyDescriptor): boolean;
    revert(): void;
}
//# sourceMappingURL=PatchRegistry.d.ts.map