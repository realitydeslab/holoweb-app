/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
export { RemoteControlInterface } from './RemoteControlInterface.js';
export type { DeviceId, PoseDeviceId, ConnectedInputDeviceId, SelectableDeviceId, InputDeviceId, ControllerId, Action, DiscreteAction, TickAction, DurationAction, OrientationInput, DirectionInput, HandOrientationInput, PlacementOrientationInput, GetTransformParams, GetTransformResult, SetTransformParams, SetTransformResult, LookAtParams, LookAtResult, AnimateToParams, AnimateToResult, SetInputModeParams, SetInputModeResult, SetConnectedParams, SetConnectedResult, GetSelectValueParams, GetSelectValueResult, SetSelectValueParams, SetSelectValueResult, SetHandPoseParams, SetHandPoseResult, GetHandStateParams, GetHandStateResult, MicrogestureParams, MicrogestureResult, SequencePosition, SequenceTarget, TargetFace, TargetIntent, ResolvedTarget, TargetResolver, TimedInput, SequenceStep, RunSequenceParams, SequenceResult, SequencePlan, CancelSequenceResult, ListTargetsResult, SelectParams, SelectResult, GamepadButtonInfo, GamepadAxisInfo, GetGamepadStateParams, GetGamepadStateResult, GamepadButtonInput, GamepadAxisInput, SetGamepadStateParams, SetGamepadStateResult, RemoteSessionStatus, AcceptSessionResult, EndSessionResult, RemoteDeviceState, RemoteHandState, SetDeviceStateParams, SetDeviceStateResult, } from './types.js';
export type { Easing, NamedDirection } from './hand-motion.js';
export { MICROGESTURES } from './microgesture.js';
export type { Microgesture } from './microgesture.js';
//# sourceMappingURL=index.d.ts.map