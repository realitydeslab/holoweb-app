/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { Easing } from './hand-motion.js';
/**
 * What a channel animates on its device: where it is (`transform`), a hand's
 * pose (`pose`), its select value (`pinch`) or a thumb microgesture on top
 * of the pose (`thumb`).
 */
export type ChannelKind = 'transform' | 'pose' | 'pinch' | 'thumb';
/**
 * One aspect of one device animated over time. Remote control's timed
 * commands each run one channel; several channels of a device can run
 * together (run_sequence, tests).
 */
export interface Channel {
    device: string;
    kind: ChannelKind;
    /** Milliseconds from the start of the run to the start of this channel. */
    delayMs?: number;
    durationMs: number;
    easing: Easing;
    /** Called when the channel starts: captures where it animates from. */
    begin?: () => void;
    /** Applies eased progress, from 0 to 1 (exactly 1 on its last frame). */
    apply: (progress: number) => void;
    /**
     * Called once if the channel stops before it finishes (begun or not), so
     * it can undo what it would otherwise leave behind (a pressed button).
     */
    cancel?: () => void;
}
/**
 * Channels started together. A run advances only on the time it is given
 * (remote control's queue time), so a frame's leftover time can carry into
 * whatever runs next.
 */
export declare class ChannelRun {
    private engine;
    private states;
    private elapsed;
    private stoppedEarly;
    /** When the last channel ends, in milliseconds from the start of the run. */
    readonly endMs: number;
    constructor(engine: ChannelEngine, channels: Channel[]);
    /** Milliseconds this run has advanced. */
    get elapsedMs(): number;
    /** True once every channel has finished or been stopped. */
    get done(): boolean;
    /**
     * True when a channel was stopped before it finished (by `stop()`, by the
     * engine, or by a later run taking its slot).
     */
    get interrupted(): boolean;
    /**
     * Advances every channel by `deltaMs`. Returns the time left over once all
     * of them have finished (for whatever runs next), or -1 while any is still
     * running. A channel replaced by a later run stops where it is.
     */
    advance(deltaMs: number): number;
    /** Stops every channel of this run where it is. */
    stop(): void;
}
/**
 * Keeps track of which run owns each device's channels: one channel of each
 * kind per device. Starting a channel replaces the one of the same kind on
 * the same device, which stops where it is.
 */
export declare class ChannelEngine {
    private owners;
    /** Starts `channels` together; nothing moves until the run advances. */
    run(channels: Channel[]): ChannelRun;
    /** True while any channel (of `device`, when given) is running. */
    isActive(device?: string): boolean;
    /** Stops every channel, or every channel of `device`, where it is. */
    stop(device?: string): void;
    /** @internal Whether `run` still owns `channel`'s slot. */
    owns(run: ChannelRun, channel: Channel): boolean;
    /** @internal Frees `channel`'s slot if `run` still owns it. */
    release(run: ChannelRun, channel: Channel): void;
}
//# sourceMappingURL=channels.d.ts.map