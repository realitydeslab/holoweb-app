/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import type { XRDevice } from '../device/XRDevice.js';
import type { AnimateToParams, SetSelectValueParams, AcceptSessionResult, SetHandPoseParams, RunSequenceParams, SequencePlan, SequenceResult, TargetResolver } from './types.js';
/**
 * RemoteControlInterface provides frame-synchronized programmatic control of an XRDevice.
 *
 * This class implements a command queue that processes actions during each frame update,
 * enabling smooth animations and coordinated control with DevUI.
 *
 * Key features:
 * - Frame-synchronized execution: Commands are queued and processed during frame update
 * - Duration-based actions: Smooth animations via lerp over multiple frames
 * - Automatic capture/release: Captures device on first command, releases 30s after queue empties
 * - Unified device identifiers: 'headset', 'controller-left', 'hand-right', etc.
 *
 * Usage:
 * ```typescript
 * import { XRDevice, metaQuest3 } from 'iwer';
 *
 * const device = new XRDevice(metaQuest3);
 * device.installRuntime();
 *
 * // Get transform
 * const result = await device.remote.dispatch('get_transform', { device: 'headset' });
 *
 * // Animate headset to new position over 1 second
 * await device.remote.dispatch('animate_to', {
 *   device: 'headset',
 *   position: { x: 0, y: 1.6, z: -1 },
 *   duration: 1.0
 * });
 * ```
 */
export declare class RemoteControlInterface {
    private device;
    private commandQueue;
    private _isCaptured;
    private releaseTimer;
    private actionIdCounter;
    /** Release timeout in milliseconds (default: 30000 = 30 seconds) */
    readonly RELEASE_TIMEOUT_MS = 30000;
    /**
     * Queue watchdog in milliseconds. Queued actions are rejected when no frame
     * arrives for this long, so callers don't hang forever when the XR render
     * loop is paused. Frames that keep arriving keep the queue alive, however
     * long the actions ahead of it run.
     */
    readonly ACTION_TIMEOUT_MS = 10000;
    private watchdog;
    /** Per-device channels (transform, pose, pinch) that timed commands run. */
    private channels;
    private targetResolver;
    private sequenceBody;
    /** A run_sequence gives up this long after dispatch, under the 30 s bridge timeout. */
    readonly SEQUENCE_DEADLINE_MS = 28000;
    constructor(device: XRDevice);
    private generateActionId;
    /**
     * Whether the device is currently captured for programmatic control.
     * When true, DevUI should go into passive mode (sync FROM device only).
     */
    get isCaptured(): boolean;
    /**
     * Number of pending actions in the queue
     */
    get queueLength(): number;
    /**
     * Enqueue a discrete action for processing
     */
    private enqueueDiscrete;
    /**
     * Enqueue a timed action: `start` runs on its first frame, `tick` advances
     * it until it reports the time left over, then it resolves with `result`.
     */
    private enqueueTick;
    /**
     * Enqueue channels that run together as one timed action. `build` runs when
     * the action reaches the head of the queue (so channels capture their start
     * state, and hands are checked, then); the action holds the head until
     * every channel finishes and resolves with `result(elapsedMs)`. Timed
     * commands run one channel each; run_sequence and tests drive several.
     */
    private enqueueChannels;
    /**
     * Settles every queued action after an interruption: a started action that
     * can report partial progress (a sequence) resolves with it, the rest
     * reject with `message(method)`.
     */
    private interruptQueue;
    /** Roughly how long the queued commands still run, in milliseconds. */
    private queuedMs;
    /**
     * (Re)arm the queue watchdog. Called on every enqueue and every frame, so it
     * only fires when frames stop arriving while actions are waiting.
     */
    private armWatchdog;
    /**
     * Update method called each frame by XRDevice.
     * Processes the command queue and handles duration-based animations.
     *
     * @param deltaTimeMs - Time since last frame in milliseconds
     */
    update(deltaTimeMs: number): void;
    private startReleaseTimer;
    private cancelReleaseTimer;
    /**
     * Get the transform (position, quaternion) for a device
     */
    private getDeviceTransform;
    /**
     * Set the transform for a device
     */
    private setDeviceTransform;
    /**
     * The XR origin in GlobalSpace: the app's first non-viewer reference space,
     * or null (identity) without one. Remote positions, orientations and
     * directions are all relative to it.
     */
    private originMatrix;
    /** Transform a position from XR-origin coordinates to GlobalSpace. */
    private transformXROriginToGlobal;
    /** Transform a position from GlobalSpace to XR-origin coordinates. */
    private transformGlobalToXROrigin;
    private originRotation;
    /** Transform an orientation from XR-origin coordinates to GlobalSpace. */
    private orientationToGlobal;
    /** Transform an orientation from GlobalSpace to XR-origin coordinates. */
    private orientationToXROrigin;
    /** A device transform in XR-origin coordinates. */
    private getDeviceTransformInOrigin;
    /** Set a device transform given in XR-origin coordinates. */
    private setDeviceTransformInOrigin;
    private handFor;
    /**
     * Throws unless the hand is what the app currently sees: hand input mode,
     * connected, and hand tracking enabled on the session.
     */
    private requireLiveHand;
    /**
     * Lets go of both hands: every channel (moves, pose fades, pinch ramps)
     * stops where it is, a pose fade snaps to its pose, and pins are dropped.
     * Hands stay where they are.
     */
    private releaseHands;
    /** The body frame from the headset (its position and yaw), in GlobalSpace. */
    private bodyFrame;
    private toVec3;
    /**
     * A direction input (XR-origin vector, or a name relative to the headset's
     * yaw, or to `body` when given) as a GlobalSpace unit vector. `from`
     * (GlobalSpace) is the point toward-head / away-from-head start at.
     */
    private directionToGlobal;
    /**
     * Resolves a placement orientation for a hand. Returns the wanted wrist
     * rotation (hand directions or 'auto'), or the target-ray rotation
     * (quaternion / euler), in GlobalSpace.
     */
    private resolveHandOrientation;
    private wristFromDirections;
    /**
     * Where an anchor of the hand is now, in GlobalSpace (a grasp point at
     * `graspPinch`, else at the pin's).
     */
    private anchorPosition;
    private requireAnchor;
    private requireEasing;
    private requireDuration;
    /** True when a placement for a hand needs the anchor/pin path. */
    private isHandPlacement;
    /**
     * Get the select value for an input device (trigger for controller, pinch for hand)
     */
    private getDeviceSelectValue;
    /**
     * Set the select value for an input device
     */
    private setDeviceSelectValue;
    /**
     * Set connected state for an input device
     */
    private setDeviceConnected;
    private executeDiscreteAction;
    private executeGetSessionStatus;
    private executeAcceptSession;
    private executeEndSession;
    private executeGetTransform;
    private executeSetTransform;
    /**
     * Places a hand by an anchor and/or a hand orientation, and pins it there:
     * the anchor stays put (and the wrist keeps its rotation) while the hand's
     * shape changes.
     */
    private placeHand;
    private executeLookAt;
    private executeSetInputMode;
    private executeSetConnected;
    private executeGetSelectValue;
    private executeSetSelectValue;
    private executeSetHandPose;
    /** Validates set_hand_pose's pose and finger blends against the hand's poses. */
    private parseHandPose;
    private executeGetHandState;
    private requireSem;
    private executeGetObjects;
    private executeGetWorldState;
    /**
     * Describe the methods this interface exposes so an agent (or an MCP bridge)
     * can discover capabilities at runtime rather than relying on hard-coded
     * strings. `immediate` methods run synchronously; `requiresSession` methods
     * are queued and need an active, rendering XR session.
     */
    listMethods(): {
        method: string;
        immediate: boolean;
        requiresSession: boolean;
    }[];
    /** Alias for {@link listMethods}; returns the capability manifest. */
    describe(): ReturnType<RemoteControlInterface['listMethods']>;
    /**
     * Opt-in transport bridge. Connect a message port (a MessagePort, Worker, or
     * WebSocket-like object) so a remote agent can drive the device by posting
     * `{ id, method, params }` envelopes and receiving `{ id, result }` or
     * `{ id, error }` replies. Kept out of the constructor to preserve the
     * dependency-light, in-process default.
     */
    connectTransport(port: {
        postMessage(message: unknown): void;
        addEventListener(type: 'message', listener: (event: {
            data: unknown;
        }) => void): void;
    }): void;
    private executeGetGamepadState;
    private executeSetGamepadState;
    private executeGetDeviceState;
    private executeSetDeviceState;
    private applyInputState;
    /**
     * Set of methods that execute immediately (synchronously) without going through the queue.
     * These are queries and session management commands that need to work outside of XR frames.
     */
    private static readonly IMMEDIATE_METHODS;
    /**
     * Set of immediate methods that are "active" - they modify state and should trigger capture mode.
     * Passive methods (queries) should NOT trigger capture mode.
     */
    private static readonly ACTIVE_IMMEDIATE_METHODS;
    /**
     * Queued methods that write a device's buttons. A second write to the same
     * device waits for the next frame, so a press and its release never land
     * in one frame (see update()).
     */
    private static readonly INPUT_WRITE_METHODS;
    /**
     * Queued methods that end the queue's work for the frame: they change which
     * input sources exist, which the app hears about before any edge.
     */
    private static readonly FRAME_ENDING_METHODS;
    /**
     * Set of methods that require an active XR session.
     * These are state-modifying methods that are processed during frame updates.
     */
    private static readonly SESSION_REQUIRED_METHODS;
    /**
     * Activate capture mode for programmatic control.
     * Called when active methods are executed.
     */
    private activateCaptureMode;
    /**
     * Dispatch a method call.
     *
     * Immediate methods (queries, session management) execute synchronously.
     * State-modifying methods require an active session and are queued for frame-synchronized execution.
     *
     * @param method - The method name (e.g., 'get_transform', 'animate_to')
     * @param params - The method parameters
     * @returns Promise that resolves with the method result
     */
    dispatch(method: string, params?: Record<string, unknown>): Promise<unknown>;
    /**
     * Execute an immediate method synchronously (not queued).
     * Used for queries and session management that must work outside XR frames.
     */
    private executeImmediateMethod;
    /**
     * The select value last written for a device: the one waiting for the next
     * frame, else the current one.
     */
    private latestSelectValue;
    /** A pinch (or trigger) ramp from the value it starts at to `value`. */
    private pinchChannel;
    /** A pose fade from the hand as shown when it starts. */
    private poseChannel;
    /**
     * The transform channel of animate_to. A hand placed by an anchor or by hand
     * directions moves its pin (the anchor's path, and the wrist's rotation);
     * anything else moves the device pose as before. Start and target are
     * taken when the channel starts.
     */
    private moveChannel;
    /** animate_to: one transform channel; the start pose is taken when it starts. */
    private enqueueAnimateTo;
    /** set_select_value with a duration: ramps from the current value. */
    private enqueueSelectRamp;
    /** set_hand_pose with a duration: fades from the hand as shown. */
    private enqueuePoseFade;
    /**
     * @internal Runs a move, a pose fade and a pinch ramp of one hand together,
     * as one queued action (each takes the params of animate_to, set_hand_pose
     * or set_select_value, without the device). Resolves with get_hand_state
     * once all of them finish. Not a remote method: the channel engine's entry
     * point for hand sequences and tests.
     */
    runHandMotion(deviceId: 'hand-left' | 'hand-right', motion: {
        move?: Omit<AnimateToParams, 'device'>;
        pose?: Omit<SetHandPoseParams, 'device'>;
        pinch?: Omit<SetSelectValueParams, 'device'>;
    }): Promise<unknown>;
    /**
     * Execute select action: press, hold `duration`, release, on the device's
     * pinch channel. A hand closes its pinch over 0.1 s and opens it over 0.1 s
     * around the hold; a controller steps its trigger. Each edge lands on its
     * own frame.
     */
    private executeSelectSequence;
    /**
     * microgesture: the thumb swipes or taps on the side of the index finger
     * and the gesture's hand gamepad button pulses for 35 ms, as on Quest. A
     * hand not in the microgesture pose takes it first (0.25 s), letting go of
     * a light pinch; a hand that is selecting must let go first. Runs the
     * pose, pinch and thumb channels of the hand as one queued action.
     */
    private enqueueMicrogesture;
    /**
     * Registers how run_sequence steps turn `target` names into points in the
     * scene: an app framework knows its objects, IWER doesn't. Pass null to
     * remove it.
     */
    setTargetResolver(resolver: TargetResolver | null): void;
    /** Runs a hand sequence; same as `dispatch('run_sequence', params)`. */
    runSequence(params: RunSequenceParams): Promise<SequenceResult | SequencePlan>;
    /** What the sequence runner needs from remote control. */
    private sequenceHost;
    /**
     * run_sequence: validated and planned at dispatch (a dry run answers right
     * away), then run as one timed action holding the head of the queue.
     */
    private enqueueSequence;
    /**
     * cancel_sequence: stops a running sequence at the current frame. Fades,
     * ramps and pins are let go; the pinch stays as it is.
     */
    private executeCancelSequence;
    /** list_targets: what the page's target resolver knows. */
    private executeListTargets;
    /**
     * Accept an offered XR session (async wrapper for proper session activation)
     */
    acceptSession(): Promise<AcceptSessionResult>;
    /**
     * Called when the XR session ends: queued commands can't run against a
     * session that is gone, so they are rejected instead of resuming in the
     * next session.
     */
    onSessionEnd(): void;
    /**
     * Force release capture mode (for testing/cleanup)
     */
    forceRelease(): void;
    /**
     * Cancel every held button on both controllers and hands: values drop to 0
     * and a press the app saw ends with `selectend`/`squeezeend` alone.
     */
    private cancelHeldInputs;
}
//# sourceMappingURL=RemoteControlInterface.d.ts.map