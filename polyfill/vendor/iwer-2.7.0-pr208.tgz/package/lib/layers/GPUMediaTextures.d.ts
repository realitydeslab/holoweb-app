/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import type { GPULayerTextureSet } from './GPULayerTextures.js';
import type { WebGPUDevice } from '../types/webgpu.js';
/**
 * The image of a media layer. Each time IWER composites, it copies the video's
 * current frame into a texture on its own GPUDevice.
 */
export declare class GPUMediaTextures {
    readonly video: HTMLVideoElement;
    readonly invertStereo: boolean;
    device: WebGPUDevice | null;
    readonly current: null;
    readonly releasedFrame: null;
    released: GPULayerTextureSet | null;
    destroyed: boolean;
    private texture;
    private warned;
    private lost;
    constructor(video: HTMLVideoElement, invertStereo: boolean);
    private requestDevice;
    /**
     * Copies the video's current frame for the compositor. A video with no frame
     * to show leaves the layer transparent, as the Layers spec describes.
     */
    update(): void;
    destroy(): void;
}
//# sourceMappingURL=GPUMediaTextures.d.ts.map