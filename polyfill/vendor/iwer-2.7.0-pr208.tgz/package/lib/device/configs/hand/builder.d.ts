/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import type { HandPose } from '../../XRHandInput.js';
/**
 * Joint angles for one finger, in degrees. Flexion is positive toward the
 * palm; `yaw` is the side-to-side angle at the knuckle (negative toward the
 * thumb); `roll` twists the finger about its own axis. Omitted values keep the
 * skeleton's rest value.
 */
export interface FingerAngles {
    mcp?: number;
    pip?: number;
    dip?: number;
    yaw?: number;
    roll?: number;
    pipYaw?: number;
    pipRoll?: number;
}
/**
 * Thumb angles, in degrees. `cmc` is the thumb metacarpal's [yaw, pitch, roll]
 * relative to the wrist: negative yaw swings the thumb away from the index,
 * negative pitch moves it toward the palm side, and negative roll turns the
 * thumb pad toward the fingers. `shift` (0 to 1) moves the thumb base toward
 * its position in the opposed (pinch) skeleton.
 */
export interface ThumbAngles {
    cmc?: [number, number, number];
    shift?: number;
    mcp?: number;
    ip?: number;
    mcpYaw?: number;
    mcpRoll?: number;
    ipYaw?: number;
    ipRoll?: number;
}
export interface HandPoseAngles {
    thumb?: ThumbAngles;
    index?: FingerAngles;
    middle?: FingerAngles;
    ring?: FingerAngles;
    pinky?: FingerAngles;
}
/**
 * Builds a hand pose from joint angles on the skeleton of `rest`: finger bone
 * lengths (metacarpal to tip), the finger bases, joint radii, wrist and grip
 * placement all come from `rest`, so every pose built from the same skeleton
 * can be blended finger by finger. The one exception is the thumb base:
 * `thumb.shift` moves it toward its position in `opposed`.
 * Left-hand convention, like every pose config.
 */
export declare const buildHandPose: (angles: HandPoseAngles, rest: HandPose, opposed: HandPose) => HandPose;
//# sourceMappingURL=builder.d.ts.map