/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { XRDeviceConfig } from '../../XRDevice.js';
import type { XRVisibilityMask } from '../../XRVisibilityMask.js';
/**
 * Angular bounds sampled from Meta VR Glasses XRView projection matrices. The same
 * projection was reported for both eyes in immersive-vr and immersive-ar.
 */
export declare const metaVRGlassesVisibilityMask: XRVisibilityMask;
export declare const oculusQuest1: XRDeviceConfig;
export declare const metaQuest2: XRDeviceConfig;
export declare const metaQuestPro: XRDeviceConfig;
export declare const metaQuest3: XRDeviceConfig;
/** Quest-compatible input/runtime profile with Meta VR Glasses' narrower view mask. */
export declare const metaVRGlasses: XRDeviceConfig;
//# sourceMappingURL=meta.d.ts.map