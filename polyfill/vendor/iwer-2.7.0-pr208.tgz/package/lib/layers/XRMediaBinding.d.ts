/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { P_MEDIA_BINDING } from '../private.js';
import { XRSession } from '../session/XRSession.js';
import { XRCylinderLayer, XREquirectLayer, XRQuadLayer } from './XRSpaceLayers.js';
import type { XRLayerLayout } from './XRProjectionLayer.js';
import type { XRRigidTransform } from '../primitives/XRRigidTransform.js';
import type { XRSpace } from '../spaces/XRSpace.js';
export interface XRMediaLayerInit {
    space: XRSpace;
    layout?: XRLayerLayout;
    invertStereo?: boolean;
}
export interface XRMediaQuadLayerInit extends XRMediaLayerInit {
    transform?: XRRigidTransform | null;
    width?: number | null;
    height?: number | null;
}
export interface XRMediaCylinderLayerInit extends XRMediaLayerInit {
    transform?: XRRigidTransform | null;
    radius?: number;
    centralAngle?: number;
    aspectRatio?: number | null;
}
export interface XRMediaEquirectLayerInit extends XRMediaLayerInit {
    transform?: XRRigidTransform | null;
    radius?: number;
    centralHorizontalAngle?: number;
    upperVerticalAngle?: number;
    lowerVerticalAngle?: number;
}
/**
 * Creates layers that show a video, for WebGPU sessions with the 'layers'
 * feature. IWER copies the video's current frame each time it composites.
 */
export declare class XRMediaBinding {
    [P_MEDIA_BINDING]: {
        session: XRSession;
    };
    constructor(session: XRSession);
    createQuadLayer(video: HTMLVideoElement, init?: XRMediaQuadLayerInit): XRQuadLayer;
    createCylinderLayer(video: HTMLVideoElement, init?: XRMediaCylinderLayerInit): XRCylinderLayer;
    createEquirectLayer(video: HTMLVideoElement, init?: XRMediaEquirectLayerInit): XREquirectLayer;
    private validateCreation;
}
/**
 * Makes XRMediaBinding IWER's while a WebGPU session with layers runs, and
 * returns a function that puts back what was there before. IWER doesn't keep
 * it defined: the WebXR Layers polyfill, which draws WebGL sessions' layers,
 * only installs itself where XRMediaBinding is missing.
 */
export declare const defineMediaBinding: () => (() => void);
//# sourceMappingURL=XRMediaBinding.d.ts.map