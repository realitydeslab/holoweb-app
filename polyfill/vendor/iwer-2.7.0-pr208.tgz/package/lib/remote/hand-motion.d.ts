/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { quat, vec3 } from 'gl-matrix';
import type { HandDirections } from '../device/XRHandInput.js';
import { XRHandedness } from '../input/XRInputSource.js';
/** Time curves for timed remote commands. */
export type Easing = 'linear' | 'minimum-jerk';
export declare const EASINGS: readonly Easing[];
/**
 * Easings run_sequence also uses internally: `reach` is minimum-jerk skewed
 * so the hand speeds up quickly and slows down for longer (peak speed at 40%
 * of the time), as a reach to a target does. Not a remote `easing` value.
 */
export type PathEasing = Easing | 'reach';
/**
 * Maps linear progress (0 to 1) through an easing. `minimum-jerk` is the
 * smooth start-and-stop profile of a human reach (10t³ − 15t⁴ + 6t⁵).
 */
export declare const ease: (easing: PathEasing, t: number) => number;
/** Directions that can be named instead of given as a vector. */
export declare const NAMED_DIRECTIONS: readonly ["up", "down", "forward", "back", "left", "right", "toward-head", "away-from-head"];
export type NamedDirection = (typeof NAMED_DIRECTIONS)[number];
/**
 * The body's frame: the head position and the horizontal directions the body
 * faces. `forward` and `right` ignore head pitch and roll.
 */
export interface BodyFrame {
    head: vec3;
    forward: vec3;
    right: vec3;
}
/** The body frame implied by a head pose (its yaw only). */
export declare const bodyFrameFromHead: (head: vec3, headRotation: quat) => BodyFrame;
/**
 * A direction as a unit vector. Named directions are relative to the body
 * frame; `toward-head` / `away-from-head` need the point they start from.
 */
export declare const resolveDirection: (value: vec3 | NamedDirection, body: BodyFrame, from?: vec3) => vec3;
/**
 * Where a hand's shoulder roughly is: 18 cm to the side of, 25 cm below and
 * 5 cm behind the eyes, in the body frame.
 */
export declare const shoulderPosition: (body: BodyFrame, handedness: XRHandedness) => vec3;
/**
 * A natural reaching orientation: fingers pointing along the forearm (from an
 * elbow estimate below and in front of the shoulder to the target), turned
 * part of the way back toward straight ahead, palm down and rolled 15° toward
 * thumb-up, the way a relaxed arm reaches.
 */
export declare const autoDirections: (shoulder: vec3, target: vec3, handedness: XRHandedness, body: BodyFrame) => HandDirections;
//# sourceMappingURL=hand-motion.d.ts.map