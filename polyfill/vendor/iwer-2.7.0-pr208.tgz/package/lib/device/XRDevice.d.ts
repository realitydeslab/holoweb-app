/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { GlobalSpace, XRSpace } from '../spaces/XRSpace.js';
import { P_DEVICE } from '../private.js';
import { Quaternion, Vector3 } from '../utils/Math.js';
import type { ControlMode } from '../types/state.js';
import { RemoteControlInterface } from '../remote/RemoteControlInterface.js';
import { XRController, XRControllerConfig } from './XRController.js';
import { XREnvironmentBlendMode, XRInteractionMode, XRSession, XRSessionMode, XRVisibilityState } from '../session/XRSession.js';
import { XREye, XRView } from '../views/XRView.js';
import { XRHandInput } from './XRHandInput.js';
import { XRHandedness, XRInputSource } from '../input/XRInputSource.js';
import { XRWebGLLayer } from '../layers/XRWebGLLayer.js';
import { XRReferenceSpace } from '../spaces/XRReferenceSpace.js';
import { mat4 } from 'gl-matrix';
import { ActionPlayer, ActionPlayerOptions, CompressedRecording } from '../action/ActionPlayer.js';
import { XRFrame } from '../frameloop/XRFrame.js';
import { XRSystem } from '../initialization/XRSystem.js';
import { XRTrackedInput } from './XRTrackedInput.js';
import { XRGazeInput } from './XRGazeInput.js';
import { XRViewport } from '../views/XRViewport.js';
import { NativePlane } from '../planes/XRPlane.js';
import { NativeMesh } from '../meshes/XRMesh.js';
import type { DepthSensingData } from '../depth/XRDepthInformation.js';
import type { XRRuntimeAdapter } from '../types/runtime-session.js';
import { type XRVisibilityMask } from './XRVisibilityMask.js';
export type WebXRFeature = 'viewer' | 'local' | 'local-floor' | 'bounded-floor' | 'unbounded' | 'dom-overlay' | 'anchors' | 'plane-detection' | 'mesh-detection' | 'hit-test' | 'hand-tracking' | 'gaze-tracking' | 'eye-tracking' | 'depth-sensing' | 'webgpu' | 'layers' | 'space-warp';
export interface XRDeviceConfig {
    name: string;
    controllerConfig: XRControllerConfig | undefined;
    supportedSessionModes: XRSessionMode[];
    supportedFeatures: WebXRFeature[];
    supportedFrameRates: number[];
    isSystemKeyboardSupported: boolean;
    internalNominalFrameRate: number;
    environmentBlendModes: Partial<{
        [sessionMode in XRSessionMode]: XREnvironmentBlendMode;
    }>;
    interactionMode: XRInteractionMode;
    userAgent: string;
    /** Optional per-eye angular mask used to preview a narrower headset FOV. */
    visibilityMask?: XRVisibilityMask;
}
export interface XRDeviceOptions {
    ipd: number;
    fovy: number;
    stereoEnabled: boolean;
    headsetPosition: Vector3;
    headsetQuaternion: Quaternion;
    canvasContainer: HTMLDivElement;
    /** Override or disable the device config's visibility mask. */
    visibilityMask: XRVisibilityMask | null;
    /** Whether a configured visibility mask starts enabled. */
    visibilityMaskEnabled: boolean;
}
export interface DevUIConstructor {
    new (xrDevice: XRDevice): DevUI;
}
export interface DevUI {
    version: string;
    render(time: number): void;
    applyDefaultPose?(defaultPose: unknown): void;
    setGazeMode?(mode: 'off' | 'cursor' | 'head-locked'): void;
    setGazeCommitHand?(handedness: 'left' | 'right'): void;
    onSessionEnd?(): void;
    get devUICanvas(): HTMLCanvasElement;
    get devUIContainer(): HTMLDivElement;
}
export interface SEMConstructor {
    new (xrDevice: XRDevice): SyntheticEnvironmentModule;
}
export interface SyntheticEnvironmentModule {
    version: string;
    render(time: number): void;
    loadEnvironment(json: unknown): void;
    loadDefaultEnvironment(envId: string): Promise<void>;
    /** Adds a `.glts` environment that loadDefaultEnvironment(id) can load. */
    addEnvironment?(id: string, url: string | URL): void;
    /** Ids of the built-in and added environments. */
    readonly environments?: string[];
    /** Whether an environment is a built-in room, added, or a legacy scan. */
    environmentInfo?(id: string): {
        kind: 'room' | 'added' | 'legacy-scan';
    } | undefined;
    planesVisible: boolean;
    boundingBoxesVisible: boolean;
    meshesVisible: boolean;
    get environmentCanvas(): HTMLCanvasElement;
    get trackedPlanes(): Set<NativePlane>;
    get trackedMeshes(): Set<NativeMesh>;
    deleteAll(): void;
    computeHitTestResults(rayMatrix: mat4): mat4[];
    computeDepthBuffer(viewMatrix: mat4, projectionMatrix: mat4, width: number, height: number, depthNear: number, depthFar: number): DepthSensingData | null;
}
/**
 * Host object that receives or supplies WebXR constructor globals. Both arms
 * are load-bearing: the record arm accepts partial test doubles, and the
 * `typeof globalThis` arm keeps `window` (typed `Window & typeof globalThis`)
 * assignable without a cast. Do not collapse to one.
 */
export type XRGlobalObject = typeof globalThis | Record<string, unknown>;
type GlobalObjectRecord = Record<string, unknown>;
export interface RuntimeOptions {
    globalObject?: XRGlobalObject;
    polyfillLayers?: boolean;
    /**
     * When a native `navigator.xr` is already present, installRuntime skips
     * clobbering the existing runtime and warns instead. Set this to `true` to
     * force the emulated runtime to be installed over the native one. Required for
     * browser-extension use, where the whole point is to override native WebXR.
     */
    forceInstall?: boolean;
}
/** Longest frame delta remote control advances by in one frame. */
export declare const MAX_REMOTE_FRAME_MS = 100;
/**
 * XRDevice is not a standard API class outlined in the WebXR Device API Specifications
 * Instead, it serves as an user-facing interface to control the emulated XR Device
 */
export declare class XRDevice {
    readonly version = "2.7.0";
    [P_DEVICE]: {
        name: string;
        supportedSessionModes: string[];
        supportedFeatures: WebXRFeature[];
        supportedFrameRates: number[];
        isSystemKeyboardSupported: boolean;
        internalNominalFrameRate: number;
        environmentBlendModes: Partial<{
            [sessionMode in XRSessionMode]: XREnvironmentBlendMode;
        }>;
        interactionMode: XRInteractionMode;
        userAgent: string;
        position: Vector3;
        quaternion: Quaternion;
        stereoEnabled: boolean;
        ipd: number;
        fovy: number;
        visibilityMask?: XRVisibilityMask;
        visibilityMaskEnabled: boolean;
        visibilityMaskCanvas?: HTMLCanvasElement;
        controllers: {
            [key in XRHandedness]?: XRController;
        };
        hands: {
            [key in XRHandedness]?: XRHandInput;
        };
        gaze?: XRGazeInput;
        primaryInputMode: 'controller' | 'hand';
        pendingReferenceSpaceReset: boolean;
        visibilityState: XRVisibilityState;
        pendingVisibilityState: XRVisibilityState | null;
        xrSystem: XRSystem | null;
        installedGlobalObject: GlobalObjectRecord | null;
        previousNavigatorXRDescriptor: PropertyDescriptor | null;
        previousUserAgentDescriptor: PropertyDescriptor | null;
        previousGlobals: Map<string, {
            existed: boolean;
            value: unknown;
        }> | null;
        previousMakeXRCompatible: Map<object, {
            existed: boolean;
            descriptor: PropertyDescriptor | undefined;
        }> | null;
        matrix: mat4;
        globalSpace: GlobalSpace;
        viewerSpace: XRReferenceSpace;
        viewSpaces: {
            [key in XREye]: XRSpace;
        };
        canvasData?: {
            canvas: HTMLCanvasElement;
            parent: HTMLElement | null;
            width: number;
            height: number;
            zIndex: string;
        };
        canvasContainer: HTMLDivElement;
        getViewport: (layer: XRWebGLLayer, view: XRView) => XRViewport;
        viewportCache: {
            [key in XREye]?: XRViewport;
        };
        getRecommendedViewResolution: () => {
            width: number;
            height: number;
        };
        updateViews: () => void;
        mountCanvas: (canvas: HTMLCanvasElement) => void;
        onBaseLayerSet: (baseLayer: XRWebGLLayer | null) => void;
        onSessionEnd: () => void;
        onFrameStart: (frame: XRFrame) => void;
        onSynthesizedFrame: () => void;
        updateRemote: () => void;
        actionPlayer?: ActionPlayer;
        devui?: DevUI;
        sem?: SyntheticEnvironmentModule;
        controlMode: ControlMode;
        controlModeListeners: Set<(mode: ControlMode) => void>;
        stateChangeListeners: Set<() => void>;
        remote: RemoteControlInterface;
        runtime: XRRuntimeAdapter;
        lastFrameTime: number;
    };
    constructor(deviceConfig: XRDeviceConfig, deviceOptions?: Partial<XRDeviceOptions>);
    private drawVisibilityMask;
    /**
     * Whether a native (non-emulated) WebXR runtime is already present on
     * `navigator.xr`. installRuntime uses this to avoid clobbering a real
     * runtime unless `forceInstall` is set.
     */
    isNativeXRAvailable(): boolean;
    installRuntime(options?: RuntimeOptions): void;
    /**
     * Best-effort reversal of installRuntime: restores the previous
     * navigator.xr / navigator.userAgent descriptors, the WebGL makeXRCompatible
     * methods, and the overwritten global constructors. Safe to call even if
     * installRuntime was never invoked (no-op in that case).
     */
    uninstallRuntime(): void;
    installDevUI(devUIConstructor: DevUIConstructor): void;
    installSEM(semConstructor: SEMConstructor): void;
    get supportedSessionModes(): string[];
    get supportedFeatures(): WebXRFeature[];
    get supportedFrameRates(): number[];
    get isSystemKeyboardSupported(): boolean;
    get internalNominalFrameRate(): number;
    get stereoEnabled(): boolean;
    set stereoEnabled(value: boolean);
    get ipd(): number;
    set ipd(value: number);
    get fovy(): number;
    set fovy(value: number);
    get visibilityMask(): XRVisibilityMask | undefined;
    /**
     * Whether this device's configured visibility mask is currently displayed.
     * Profiles without a visibility mask always remain disabled.
     */
    get visibilityMaskEnabled(): boolean;
    set visibilityMaskEnabled(value: boolean);
    get position(): Vector3;
    get quaternion(): Quaternion;
    get viewerSpace(): XRReferenceSpace;
    get viewSpaces(): {
        none: XRSpace;
        left: XRSpace;
        right: XRSpace;
    };
    get controllers(): {
        none?: XRController | undefined;
        left?: XRController | undefined;
        right?: XRController | undefined;
    };
    get hands(): {
        none?: XRHandInput | undefined;
        left?: XRHandInput | undefined;
        right?: XRHandInput | undefined;
    };
    get gaze(): XRGazeInput | undefined;
    get primaryInputMode(): "controller" | "hand";
    set primaryInputMode(mode: 'controller' | 'hand');
    get activeInputs(): XRTrackedInput[];
    get inputSources(): XRInputSource[];
    get canvasContainer(): HTMLDivElement;
    get canvasDimensions(): {
        width: number;
        height: number;
    } | undefined;
    /**
     * Get the app canvas when an XR session is active.
     * Returns undefined if no session is active or no canvas is available.
     */
    get appCanvas(): HTMLCanvasElement | undefined;
    get activeSession(): XRSession | undefined;
    get sessionOffered(): boolean;
    get name(): string;
    grantOfferedSession(): void;
    recenter(): void;
    get visibilityState(): XRVisibilityState;
    updateVisibilityState(state: XRVisibilityState): void;
    createActionPlayer(refSpace: XRReferenceSpace, recording: CompressedRecording, options?: ActionPlayerOptions): ActionPlayer;
    get devui(): DevUI | undefined;
    get sem(): SyntheticEnvironmentModule | undefined;
    get remote(): RemoteControlInterface;
    /**
     * Get the current control mode
     * - 'manual': User controls device via DevUI (default)
     * - 'programmatic': External API controls device
     */
    get controlMode(): ControlMode;
    /**
     * Set the control mode
     * Notifies all registered listeners of the change
     */
    set controlMode(mode: ControlMode);
    /**
     * Register a listener to be notified when control mode changes
     * @param listener - Callback function that receives the new mode
     * @returns Unsubscribe function to remove the listener
     */
    onControlModeChange(listener: (mode: ControlMode) => void): () => void;
    /**
     * Register a listener to be notified when device state changes
     * Called after programmatic state modifications
     * @param listener - Callback function
     * @returns Unsubscribe function to remove the listener
     */
    onStateChange(listener: () => void): () => void;
    /**
     * Notify all state change listeners that device state has been modified
     * Should be called after programmatic state modifications
     */
    notifyStateChange(): void;
}
export {};
//# sourceMappingURL=XRDevice.d.ts.map