/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { P_DEPTH_INFO } from '../private.js';
import { XRRigidTransform } from '../primitives/XRRigidTransform.js';
export type XRDepthUsage = 'cpu-optimized' | 'gpu-optimized';
export type XRDepthDataFormat = 'luminance-alpha' | 'float32' | 'unsigned-short';
export interface XRDepthStateInit {
    usagePreference: XRDepthUsage[];
    dataFormatPreference: XRDepthDataFormat[];
}
export interface DepthSensingData {
    data: ArrayBuffer;
    width: number;
    height: number;
    rawValueToMeters: number;
}
/**
 * Picks the first supported usage and data format from the app's preferences,
 * usage first, or null when none of them is supported.
 */
export declare const findWebGPUDepthConfiguration: (init: XRDepthStateInit | undefined) => {
    usage: XRDepthUsage;
    dataFormat: XRDepthDataFormat;
} | null;
export declare const toMillimeterDepth: (depth: DepthSensingData) => DepthSensingData;
export declare class XRCPUDepthInformation {
    [P_DEPTH_INFO]: {
        data: ArrayBuffer;
        width: number;
        height: number;
        normDepthBufferFromNormView: XRRigidTransform;
        rawValueToMeters: number;
        dataFormat: XRDepthDataFormat;
        view: Float32Array | Uint8Array;
    };
    constructor(data: ArrayBuffer, width: number, height: number, normDepthBufferFromNormView: XRRigidTransform, rawValueToMeters: number, dataFormat: XRDepthDataFormat);
    get data(): ArrayBuffer;
    get width(): number;
    get height(): number;
    get normDepthBufferFromNormView(): XRRigidTransform;
    get rawValueToMeters(): number;
    get dataFormat(): XRDepthDataFormat;
    getDepthInMeters(x: number, y: number): number;
}
//# sourceMappingURL=XRDepthInformation.d.ts.map