/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import type { XRDevice } from '../device/XRDevice.js';
import type { XRFrame } from '../frameloop/XRFrame.js';
import type { XRLayer } from './XRWebGLLayer.js';
import type { XRSession } from '../session/XRSession.js';
/**
 * Draws the layers of a WebGPU session onto IWER-owned canvases, mounted where
 * a WebGL session's canvas would be. Layers are composited in render state
 * order with source-over blending; consecutive layers on the same GPUDevice
 * share a canvas, and the canvases stack in order.
 */
export declare class XRGPUPresenter {
    private xrDevice;
    private format;
    private surfaces;
    private poses;
    constructor(xrDevice: XRDevice);
    attach(): void;
    setVisible(visible: boolean): void;
    /**
     * Shows the layers. With `synthesizeFrom`, this is a frame IWER synthesizes
     * with space warp: projection layers that submitted motion vectors in that
     * frame are extrapolated from it, and other layers show their last frame.
     */
    present(session: XRSession, layers: readonly XRLayer[], synthesizeFrom?: XRFrame | null): void;
    private synthesize;
    detach(): void;
    private surface;
    private viewRegions;
    private drawRun;
    private encodeDraw;
}
//# sourceMappingURL=XRGPUPresenter.d.ts.map