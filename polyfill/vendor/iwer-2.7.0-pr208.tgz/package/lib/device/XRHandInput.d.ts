/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { GlobalSpace } from '../spaces/XRSpace.js';
import { P_HAND_INPUT } from '../private.js';
import { XRHandJoint } from '../input/XRHand.js';
import { XRHandedness } from '../input/XRInputSource.js';
import { mat4, quat, vec3 } from 'gl-matrix';
import { XRFrame } from '../frameloop/XRFrame.js';
import { XRTrackedInput } from './XRTrackedInput.js';
import { ButtonThresholds } from '../gamepad/button-edges.js';
export interface HandPose {
    jointTransforms: {
        [joint in XRHandJoint]: {
            offsetMatrix: mat4;
            radius: number;
        };
    };
    gripOffsetMatrix?: mat4;
}
/**
 * Pinch levels at which a hand selects and lets go: press at 0.9 (fingertips
 * about 1 cm apart), release at 0.7 (about 3 cm apart), so a pinch that closes
 * gradually selects when the fingertips meet, as hand tracking does.
 */
export declare const DEFAULT_PINCH_THRESHOLDS: ButtonThresholds;
export interface XRHandInputConfig {
    profileId: string;
    fallbackProfileIds: string[];
    poses: {
        default: HandPose;
        pinch: HandPose;
        [poseId: string]: HandPose;
    };
    /**
     * Pinch press/release levels, 0 < release < press <= 1; defaults to
     * DEFAULT_PINCH_THRESHOLDS.
     */
    pinchThresholds?: ButtonThresholds;
}
export type XRHandFinger = 'thumb' | 'index' | 'middle' | 'ring' | 'pinky';
/** Joints of each finger, from the metacarpal out to the tip. */
export declare const handFingerJoints: Record<XRHandFinger, XRHandJoint[]>;
/** One finger taken (partly) from another pose. */
export interface FingerPoseBlend {
    readonly poseId: string;
    /** 0 keeps the base pose's finger, 1 uses the finger from `poseId`. */
    readonly weight: number;
}
export declare const oculusHandConfig: XRHandInputConfig;
/**
 * Hand gamepad buttons other than the pinch, from button 4: the menu gesture
 * (a palm-up pinch), then the microgestures (thumb swipes and tap).
 */
declare const HAND_GESTURE_BUTTONS: readonly ["menu", "swipe-left", "swipe-right", "swipe-forward", "swipe-backward", "tap"];
export type HandGestureButton = (typeof HAND_GESTURE_BUTTONS)[number];
/**
 * A thumb movement shown on top of the hand's pose (microgestures): the
 * thumb is `weight` of the way from its place in `from` to its place in
 * `to`, each relative to the palm.
 */
export interface ThumbMotion {
    from: HandPose;
    to: HandPose;
    weight: number;
}
/**
 * Points a hand can be placed by. `grasp` is where the thumb and index tips
 * meet when the hand fully pinches; any WebXR joint name also works.
 */
export type HandAnchor = 'target-ray' | 'wrist' | 'grip' | 'grasp' | 'index-tip' | 'thumb-tip' | XRHandJoint;
export declare const isHandAnchor: (value: unknown) => value is HandAnchor;
/**
 * A hand orientation by direction: where the fingers point (wrist -Z), and
 * either the way the palm faces (wrist -Y) or the thumb side of the hand.
 * `fingers` is kept exact; the second direction is made perpendicular to it.
 */
export interface HandDirections {
    fingers: vec3;
    palm?: vec3;
    thumb?: vec3;
}
/**
 * Where a hand is held by remote control: `anchor` stays at `target` (in
 * GlobalSpace) and, when given, the wrist keeps `wristRotation` (GlobalSpace),
 * however the hand's shape changes.
 */
export interface HandPin {
    anchor: HandAnchor;
    target: vec3;
    wristRotation?: quat;
    /** For a `grasp` anchor: the pinch the grasp point is taken at (default 1). */
    graspPinch?: number;
}
/**
 * The wrist rotation (GlobalSpace) that points a hand's fingers along
 * `fingers` with its palm facing `palm`, or its thumb side toward `thumb`.
 * The wrist frame follows WebXR: -Z along the fingers, +Y out of the back of
 * the hand. Returns null when the two directions are parallel.
 */
export declare const wristRotationFromDirections: (directions: HandDirections, handedness: XRHandedness, out?: quat) => quat | null;
export declare class XRHandInput extends XRTrackedInput {
    [P_HAND_INPUT]: {
        poseId: string;
        poses: {
            default: HandPose;
            pinch: HandPose;
            [poseId: string]: HandPose;
        };
        fingerPoses: Partial<Record<XRHandFinger, FingerPoseBlend>>;
        blendedPose: HandPose;
        blendedPoseStale: boolean;
        fingersBlended: boolean;
        transitionFrom: HandPose;
        transitionFromId: string;
        transitionProgress: number | null;
        displayedPose: HandPose;
        thumbMotion: ThumbMotion | null;
        pin: HandPin | null;
    };
    constructor(handInputConfig: XRHandInputConfig, handedness: XRHandedness, globalSpace: GlobalSpace);
    get poseId(): string;
    /**
     * Sets the whole hand to a pose and clears any finger blends. A pose change
     * in progress (beginPoseTransition) stops and the hand snaps to the pose.
     */
    set poseId(poseId: string);
    /** Ids of every pose this hand can take. */
    get poseIds(): string[];
    /** Fingers currently taken from other poses, on top of `poseId` (a copy). */
    get fingerPoses(): Partial<Record<XRHandFinger, FingerPoseBlend>>;
    /**
     * Takes one finger from another pose while the rest of the hand keeps
     * `poseId`, e.g. curl the middle, ring and pinky of `open` from `fist`.
     * `weight` blends between the base pose's finger (0) and `poseId`'s (1).
     * Each joint blends relative to its parent joint and keeps a bone length
     * between the two poses' lengths. The 21 generated poses are built on the
     * captured relaxed skeleton, so between them each finger's bones keep
     * exactly the same lengths.
     */
    setFingerPose(finger: XRHandFinger, poseId: string, weight?: number): void;
    /** Clears the blend for one finger, or for every finger if omitted. */
    clearFingerPoses(finger?: XRHandFinger): void;
    /** Rebuilds `blendedPose`; returns false when no finger is blended. */
    private blendFingers;
    /**
     * Starts a timed change to `poseId` (and finger blends): the hand fades
     * from what it shows now (before pinch, mid-fade included) as
     * `poseTransitionProgress` goes from 0 to 1. `poseId` and `fingerPoses`
     * report the new pose right away.
     */
    beginPoseTransition(poseId: string, fingers?: Partial<Record<XRHandFinger, FingerPoseBlend>>): boolean;
    /** Progress (0 to 1) of the pose change begun by beginPoseTransition, or null. */
    get poseTransitionProgress(): number | null;
    set poseTransitionProgress(progress: number | null);
    /**
     * The pose a change in progress fades from (the pose set before it), or
     * null when no change is in progress.
     */
    get poseTransitionFrom(): string | null;
    /** Where remote control holds this hand, or null. */
    get pin(): HandPin | null;
    /**
     * Holds `anchor` at `target` (GlobalSpace) from now on, re-solved every frame
     * after the hand's shape updates, optionally with a fixed wrist rotation.
     * Applies right away, to the hand's current shape. Pass null to let go.
     */
    setPin(pin: HandPin | null): void;
    /** The wrist's rotation in GlobalSpace for the hand as shown now. */
    wristRotation(out?: quat): quat;
    /**
     * An anchor's position in the target-ray frame for the hand as shown now
     * (pinch included); `grasp` is fixed for the current pose.
     */
    anchorOffset(anchor: HandAnchor, out?: vec3, graspPinch?: number): vec3;
    /**
     * The hand's axes in the target-ray frame, from the displayed wrist:
     * fingers (wrist -Z), palm (wrist -Y) and the thumb side. Mirror-safe.
     */
    handAxes(): {
        fingers: vec3;
        palm: vec3;
        thumb: vec3;
    };
    /** Re-applies the pin, if any, to the target-ray pose. */
    private solvePin;
    /** Rebuilds `displayedPose`: the pose, finger blends and any pose change. */
    private updateDisplayedPose;
    /**
     * Updates the joints and grip from the pose, finger blends, any pose change,
     * any thumb movement and the pinch, then re-solves the pin. Runs every
     * frame.
     */
    updateHandPose(): void;
    get pinchValue(): number;
    updatePinchValue(value: number): void;
    /**
     * Set pinch synchronously. Releasing a held pinch this way cancels the
     * select (`selectend` without `select`), for interaction cancellation.
     */
    setPinchValueImmediate(value: number): void;
    /**
     * The thumb movement shown on top of the pose (microgestures), or null.
     * Applies from the next pose update (every frame).
     */
    get thumbMotion(): ThumbMotion | null;
    set thumbMotion(motion: ThumbMotion | null);
    /**
     * Writes a gesture button (menu, or a microgesture) for the next frame:
     * 1 pressed, 0 released. These buttons fire no session events; apps read
     * them from the hand's gamepad.
     */
    updateGestureButton(id: HandGestureButton, value: 0 | 1): void;
    onFrameStart(frame: XRFrame): void;
}
export {};
//# sourceMappingURL=XRHandInput.d.ts.map