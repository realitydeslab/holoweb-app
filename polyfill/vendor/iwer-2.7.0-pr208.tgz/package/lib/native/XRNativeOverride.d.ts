/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { type XRDevice } from '../device/XRDevice.js';
import type { NativeOverrideCapabilities, NativeOverrideEnvironment, NativeOverrideHandle, NativeOverrideMode, NativeOverrideOptions, NativeOverrideSupport, NativeSessionInfo } from './types.js';
/**
 * Reports whether the minimum native hooks required by XRNativeOverride appear
 * to be available. Host-object patching can still fail at runtime, so install()
 * records the authoritative result in its capabilities object.
 */
export declare function getNativeOverrideSupport(environment?: NativeOverrideEnvironment): NativeOverrideSupport;
/**
 * Returns the installed override without relying on instanceof, so callers
 * can recover a handle installed by another IWER bundle or a prior HMR pass.
 */
export declare function getNativeOverride(environment?: NativeOverrideEnvironment): NativeOverrideHandle | null;
/**
 * Selectively overrides native WebXR tracking and input while preserving the
 * browser-owned XRSession, compositor, layers, frame cadence, and projections.
 *
 * Prefer installNativeOverride() for installation; direct construction is the
 * low-level path when installation must be deferred or retried.
 */
export declare class XRNativeOverride implements NativeOverrideHandle {
    readonly device: XRDevice;
    readonly mode: NativeOverrideMode;
    private readonly options;
    private xrSystem;
    private readonly globalObject;
    private readonly patches;
    private sessionsByObject;
    private readonly liveSessions;
    private frameSessions;
    private spaces;
    private hitTestBindings;
    private syntheticEvents;
    private patchedFrameOwners;
    private patchedViewerFrameOwners;
    private patchedFillPosesOwners;
    private patchedJointPoseOwners;
    private patchedJointRadiiOwners;
    private patchedReferenceSpaceOwners;
    private patchedEnabledFeaturesOwners;
    private patchedInputSourceOwners;
    private patchedRafOwners;
    private patchedRequestReferenceSpaceOwners;
    private patchedHitTestOwners;
    private patchedHitTestResultOwners;
    private patchedCreateAnchorOwners;
    private instancePatchedReferenceSpaces;
    private rawGetPoseByOwner;
    private rawGetPoseByFrame;
    private rawRafByOwner;
    private rawRequestReferenceSpaceByOwner;
    private rawInputSourcesGetterByOwner;
    private rawTransformGetters;
    private transformReaders;
    private transformOverrides;
    private patchedTransformOwners;
    private instancePatchedFrameEpochs;
    private instancePatchedTransformEpochs;
    private readonly warned;
    private readonly capabilityState;
    private readonly unhealthyFrameAdapters;
    private installedState;
    private primarySession;
    private previousRuntime;
    private epoch;
    /** Timestamp of the last frame that advanced shared device/playback state. */
    private lastPrimaryTime;
    private wiredPlayer;
    private playbackCompletions;
    private previousPlayerContext;
    /**
     * Set while a native frame samples a recording. It keeps the final sampled
     * frame observable to the application even though ActionPlayer.playFrame()
     * clears `playing` as it clamps to the end of the recording.
     */
    private playbackFrame;
    /**
     * Handed to ActionPlayer when no session owns an active frame, so an
     * application-driven stepFrames()/playFrame() still runs the player's edge
     * detection. The override re-stamps every relayed event with a real frame
     * when it drains, so this token never reaches the application.
     */
    private readonly detachedPlaybackFrame;
    constructor(device: XRDevice, options?: NativeOverrideOptions);
    get installed(): boolean;
    get capabilities(): NativeOverrideCapabilities;
    get sessions(): readonly NativeSessionInfo[];
    install(): void;
    uninstall(): void;
    /**
     * Splits a session request into what the browser is asked for and what IWER
     * answers itself. The caller's dictionary is never mutated: applications
     * legitimately reuse (and freeze) one options object across requests.
     */
    private prepareSessionRequest;
    /**
     * A session that asked for a gaze alias must never resolve without its gaze
     * source, so an override that went away mid-request fails the attach instead
     * of quietly handing back the unmodified native session.
     */
    private failWhenGazeRequested;
    private attachSession;
    private sessionEnablesHandTracking;
    private createDeviceBindings;
    private createInputBinding;
    /**
     * Returns the stable binding for a recorded playback source, creating it on
     * first use so the application always observes the same facade objects.
     */
    private playbackBinding;
    /**
     * Allocates a distinct native reference space to use as a stable synthetic
     * space token. Browsers must return a fresh object for every call, otherwise
     * IWER cannot tell the target-ray and grip spaces apart.
     */
    private createSpaceToken;
    private createInputSourceFacade;
    /**
     * Builds an XRHand-shaped maplike facade. The prototype is borrowed from the
     * browser so branded checks succeed, while every maplike method is an own
     * property because native XRHand methods reject foreign receivers.
     */
    private createHandFacade;
    /** Builds a stable XRJointSpace-shaped object for one hand joint. */
    private createJointSpaceFacade;
    private createGamepadFacade;
    private eventButtons;
    private resetButtonBaseline;
    private observeButton;
    /**
     * Forgets any in-progress action for a binding whose source just appeared or
     * disappeared, so a later removal cannot synthesize a duplicate end event.
     */
    private clearActionState;
    /**
     * Captures the browser method behind a prototype patch exactly once. A later
     * session otherwise sees IWER's wrapper as its "native" method and recurses.
     */
    private captureNativeRequestAnimationFrame;
    private captureNativeRequestReferenceSpace;
    /** Capture the browser's input-source getter before it is wrapped. */
    private captureNativeInputSources;
    /**
     * Re-reports the aliases IWER answered itself through the session property
     * applications actually read. Only patched when there is something to add,
     * so a session without synthetic features keeps the browser's own array.
     */
    private patchEnabledFeatures;
    private patchInputSources;
    private patchRequestAnimationFrame;
    private patchRequestReferenceSpace;
    private patchRequestHitTestSource;
    private tagRequestedReferenceSpace;
    private ensureReferenceSpacePatch;
    private propagateSpaceMetadata;
    private installSessionListeners;
    private tick;
    /**
     * Keep the synthetic gaze origin coincident with the physical headset while
     * leaving the browser-owned viewer pose untouched.
     */
    private syncDeviceViewerFromNative;
    private applyDeviceViewerMatrix;
    /**
     * Uses the primary session while it is visible, otherwise the first visible
     * session. Native runtimes normally expose one immersive session, but this
     * keeps shared device state live in runtimes that permit concurrent sessions.
     */
    private sharedStateDriver;
    private advanceSharedState;
    /**
     * Mirrors XRTrackedInput.onFrameStart's state advance for the inputs the
     * device currently exposes: snapshot the target-ray pose, apply pending
     * gamepad values, and refresh interpolated hand joints.
     *
     * This reads the shared device rather than any one session's bindings, so a
     * session that cannot publish a given input kind (a session without
     * hand-tracking, say) never stalls that input for the other sessions.
     */
    private updateDeviceInputs;
    private prepareFrameCallback;
    /**
     * Ends this session's ownership of the frame. WebXR marks an XRFrame inactive
     * as soon as its callback returns, so nothing may hand it to the application
     * (or query it) afterwards.
     */
    private releaseFrameCallback;
    /**
     * The recording currently driving poses and inputs, or null when the device
     * state is authoritative. Stays non-null for the remainder of the native
     * frame in which the recording reached its final sample.
     */
    private activePlayer;
    private currentViewerSpace;
    private refreshInputSources;
    private expectedSources;
    private readNativeInputSources;
    /**
     * Ends the select actions that were committed against a gaze target ray.
     *
     * Gaze carries the aim and a separate source carries the commit, so a gaze
     * source that disappears mid-press would otherwise leave the application
     * holding an interaction it can no longer point. Squeeze is untouched: it is
     * not part of the gaze-plus-pinch contract and stays with its own source.
     */
    private releaseGazeCommitActions;
    /** Drops a shared device button back to a fully released, edge-free state. */
    private releaseButton;
    private connectedSources;
    private dispatchButtonTransitions;
    /**
     * Attaches an event context so ActionPlayer's own select/squeeze edge
     * detection (including edges skipped across multi-frame advances) is routed
     * through the stable native facades instead of IWER's emulated session.
     */
    private wirePlayer;
    private unwirePlayer;
    /**
     * Queues one ActionPlayer edge on every live session, addressed to the
     * native facades.
     *
     * ActionPlayer emits WebXR order: `<trigger>start` on press, `<trigger>` then
     * `<trigger>end` on release, and `<trigger>end` alone on a cancel. The
     * completion event is held until its end arrives, so each session emits the
     * pair only for an action it saw start.
     */
    private forwardPlaybackEvent;
    private terminatePlaybackActions;
    private terminatePlaybackAction;
    /**
     * Dispatches an input event immediately when this session owns an active
     * frame, and otherwise queues it for the session's next animation frame
     * callback. `retain` keeps the source published until the queue drains.
     */
    private emitInputEvent;
    /**
     * Drops the oldest complete queued action lifecycle under backpressure.
     * Incomplete lifecycles are retained even past the soft limit: preserving
     * WebXR's start/end invariant is more important than a strict queue bound.
     */
    private compactPendingEvents;
    /** Flushes queued input events with a frame this session currently owns. */
    private drainPendingEvents;
    private dispatchInputEvent;
    /**
     * Tracks which actions the application currently believes are in progress.
     * Only delivered events count, so an event dropped while a session was not
     * visible can never produce an unmatched terminating event later.
     */
    private recordDeliveredAction;
    private dispatchInputSourcesChange;
    private createEvent;
    private ensureFramePatches;
    private patchFrameGetPose;
    private patchFrameGetViewerPose;
    private patchFrameFillPoses;
    private patchFrameGetJointPose;
    private patchFrameFillJointRadii;
    private patchFrameCreateAnchor;
    private patchFrameGetHitTestResults;
    /**
     * Records whether XRFrame.createAnchor can be intercepted. Without the
     * interception an IWER-controlled space would reach the browser untranslated
     * and silently anchor at the wrong origin, so the capability is reported and
     * controlled spaces are refused instead.
     */
    private recordAnchorAvailability;
    /**
     * Records whether XRFrame.getHitTestResults can be intercepted. Without it
     * the hit test facade would reach the browser as a foreign object, so the
     * capability is reported and controlled spaces are refused for this session.
     */
    private recordHitTestAvailability;
    private defineFrameMethod;
    private handleGetPose;
    private handleGetJointPose;
    private handleFillJointRadii;
    private handleFillPoses;
    private handleGetViewerPose;
    private viewerOverrideFailure;
    private effectivePoseMatrix;
    private viewerToBaseMatrix;
    private controlledSpaceToAnchor;
    private viewerMatrix;
    private anchorToNativeBase;
    private nativePoseMatrix;
    private createPoseFacade;
    private createJointPoseFacade;
    private poseProperties;
    private rigidTransformFromMatrix;
    private getRigidTransformConstructor;
    private readNativeTransform;
    private overrideTransform;
    private clearTransformOverrides;
    private nativeGetPose;
    private handleCreateAnchor;
    private handleRequestHitTestSource;
    private createHitTestSourceFacade;
    /**
     * Subscribes a fresh native hit test source at the given anchor-relative
     * pose, swapping it in only once the browser resolves it. The previous
     * subscription keeps serving results throughout, and survives a failure, so
     * the facade never goes blank once it has resolved a subscription.
     */
    private requestBackingSource;
    /**
     * Creates a world-locked native offset space at the given anchor-relative
     * pose. The space is deliberately untagged so native APIs treat it as an
     * ordinary browser space.
     */
    private createDetachedOffsetSpace;
    private updateHitTestSources;
    private handleGetHitTestResults;
    private cancelNativeHitTestSource;
    private disposeHitTestBinding;
    private adapterForFrame;
    /**
     * Throws if the frame is no longer the one its session owns. Browser spaces
     * already get this for free because the native call raises, but a query that
     * only touches IWER-controlled spaces never reaches the browser, and
     * answering it would let a stashed frame silently report live poses.
     */
    private assertFrameActive;
    private constructorPrototype;
    private detachSession;
    private detachAdapter;
    private resetPatchTracking;
    private unsupportedForSession;
    private unsupported;
    private note;
    private errorText;
}
/** Installs a native override and returns its lifecycle handle. */
export declare function installNativeOverride(device: XRDevice, options?: NativeOverrideOptions): XRNativeOverride;
//# sourceMappingURL=XRNativeOverride.d.ts.map