/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { quat, vec3 } from 'gl-matrix';
import type { FingerPoseBlend, HandAnchor, XRHandFinger, XRHandInput } from '../device/XRHandInput.js';
import { BodyFrame, Easing, PathEasing } from './hand-motion.js';
import type { ChannelEngine } from './channels.js';
import { MicrogesturePlayer } from './microgesture.js';
import type { Microgesture } from './microgesture.js';
import type { GamepadButton } from '../gamepad/Gamepad.js';
import type { GetHandStateResult, RunSequenceParams, SequencePlan, SequenceResult, SequenceStep, TargetResolver } from './types.js';
type HandDeviceId = RunSequenceParams['device'];
/** What the sequence runner needs from remote control (all GlobalSpace). */
export interface SequenceHost {
    /** The hand, whether or not the app sees it (validation at dispatch). */
    hand(deviceId: HandDeviceId): XRHandInput;
    /** The hand; throws unless the app sees it (when the sequence starts). */
    liveHand(deviceId: HandDeviceId): XRHandInput;
    /** The other hand, when it is connected. */
    otherHand(deviceId: HandDeviceId): XRHandInput | undefined;
    headPose(): {
        position: vec3;
        rotation: quat;
    };
    setHeadPose(position: vec3, rotation: quat): void;
    originToGlobal(position: vec3): vec3;
    globalToOrigin(position: vec3): vec3;
    originDirectionToGlobal(direction: vec3): vec3;
    globalDirectionToOrigin(direction: vec3): vec3;
    /** A direction input (vector or name) as a GlobalSpace unit vector. */
    directionToGlobal(value: unknown, what: string, from?: vec3, body?: BodyFrame): vec3;
    anchorPosition(hand: XRHandInput, anchor: HandAnchor, graspPinch?: number): vec3;
    requireAnchor(anchor: unknown): HandAnchor;
    resolveOrientation(hand: XRHandInput, orientation: unknown, target: vec3 | null, body?: BodyFrame): {
        wristRotation?: quat;
        rayRotation?: {
            x: number;
            y: number;
            z: number;
            w: number;
        };
    };
    parsePose(hand: XRHandInput, poseId: string, fingers: SequenceStep['fingers']): {
        poseId: string;
        fingers: Partial<Record<XRHandFinger, FingerPoseBlend>>;
    };
    /** Writes the pinch for the next frame. */
    setPinch(deviceId: HandDeviceId, value: number): void;
    /** The pinch last written: the one waiting for the next frame, else the current one. */
    latestPinch(deviceId: HandDeviceId): number;
    /** The hand's select button (its pinch). */
    pinchButton(deviceId: HandDeviceId): GamepadButton;
    /** One of the hand's microgesture buttons. */
    gestureButton(deviceId: HandDeviceId, gesture: Microgesture): GamepadButton;
    channels: ChannelEngine;
    resolver(): TargetResolver | null;
    handState(deviceId: HandDeviceId): GetHandStateResult;
    /**
     * The body's facing and standing head position, kept between sequences so
     * a head turned or leaned by one sequence doesn't turn or lower the body
     * for the next; null until a sequence has run.
     */
    bodyState(): {
        forward: vec3;
        standing: vec3;
    } | null;
    setBodyState(state: {
        forward: vec3;
        standing: vec3;
    }): void;
}
/** A sequence plus everything queued ahead of it must fit this, in seconds. */
export declare const SEQUENCE_BUDGET_S = 25;
/**
 * One smooth arc from `start` to `end`: a cubic Bézier that leaves along
 * `startTangent` (a lift-off) and arrives along `endTangent` (the approach,
 * pointing away from the end), sampled by arc length. With one easing over
 * its length the hand lifts, travels and comes in as a single motion, with no
 * corners and no stops.
 */
declare class ArcPath {
    private samples;
    private lengths;
    readonly length: number;
    constructor(start: vec3, end: vec3, startTangent?: {
        direction: vec3;
        distance: number;
    }, endTangent?: {
        direction: vec3;
        distance: number;
    });
    /** The point at fraction `s` (0 to 1) of the path's length. */
    at(out: vec3, s: number): vec3;
}
interface TimedValue<T> {
    value: T;
    start: number;
    end: number;
    easing: Easing;
}
/**
 * A walk (and turn) of the body: the head and the resting hand move rigidly
 * with it, and so does the acting hand when the step doesn't place it. A
 * step that places the hand walks while the arm reaches.
 */
interface BodyMove {
    /** Horizontal translation, GlobalSpace. */
    shift: vec3;
    /** Yaw turn in radians, about `pivot`. */
    turn: number;
    pivot: vec3;
    /** Seconds from the segment start, and how long it takes. */
    start: number;
    seconds: number;
    /** The acting hand goes along (pins and wrist rotation included). */
    carriesHand: boolean;
}
/** One primitive motion: a step, or part of an expanded `press`. */
interface Segment {
    step: number;
    label: string;
    kind: SequencePlan['segments'][number]['kind'];
    /** For press segments: the surface point and normal (contact timing). */
    press?: {
        point: vec3;
        normal: vec3;
    };
    /** For microgesture segments: the gesture, from `start` seconds. */
    micro?: {
        player: MicrogesturePlayer;
        start: number;
    };
    /** Computes the path and channel targets when the segment starts. */
    prepare: (ctx: RunContext) => void;
    duration: number;
    stallAfter: boolean;
    /** The next step moves the hand (a let-go leaves the lift-off to it). */
    nextPlaces?: boolean;
    /** For holds on a surface: the hand sways along it, never into it. */
    restNormal?: vec3;
    walk?: BodyMove;
    /** Lean change (head lower and forward), made with the reach. */
    lean?: vec3;
    path?: ArcPath;
    pathEasing?: PathEasing;
    pathStart?: number;
    pathEnd?: number;
    /** For holds: where the head looks ahead to (the next step's target). */
    lookAhead?: (ctx: RunContext) => vec3 | null;
    wristFrom?: quat;
    wristTo?: quat;
    pose?: TimedValue<{
        poseId: string;
        fingers: Partial<Record<XRHandFinger, FingerPoseBlend>>;
    }>;
    pinch?: TimedValue<number> & {
        from: number;
        preshape?: {
            value: number;
            start: number;
            end: number;
        };
    };
    headFrom?: {
        position: vec3;
        rotation: quat;
    };
    headTo?: {
        position: vec3;
        rotation: quat;
    };
    headStart?: number;
    headEnd?: number;
    target?: vec3;
}
interface RunContext {
    host: SequenceHost;
    params: RunSequenceParams;
    /**
     * When planning at dispatch (dry run, time budget): the pose and pinch the
     * hand will have when the next segment starts. Null while running.
     */
    planned: {
        poseId: string;
        blended: boolean;
        pinch: number;
    } | null;
    hand: XRHandInput;
    anchor: HandAnchor;
    body: BodyFrame;
    warnings: string[];
    /** The head's pose without sway, GlobalSpace (the runner keeps it current). */
    head: {
        position: vec3;
        rotation: quat;
    };
    /** Whether the other hand is lowered to rest. */
    restsOtherHand: boolean;
    /** Normal of the previous placement (GlobalSpace), for `depart`. */
    lastNormal: vec3 | null;
    /** A lift-off the next placing step makes unless it sets `depart`. */
    autoDepart: {
        normal: vec3;
        distance: number;
        fromPress?: boolean;
        fromRelease?: boolean;
    } | null;
    /** What the hand holds: its name and how far its base is below the grasp point. */
    held: {
        name: string;
        graspToBottom: number;
    } | null;
    /** The pinch the grasp point is taken at: the last closing pinch's value. */
    graspPinch: number;
    /** The direction the hand came down onto a surface from, while it rests there. */
    restNormal: vec3 | null;
    /** The body's walk (horizontal, GlobalSpace) and lean (down and forward). */
    walk: vec3;
    lean: vec3;
    /** Head position when the sequence started, before any walk or lean. */
    standingHead: vec3;
    /** Wall-clock contact windows of presses (touch within 2 cm). */
    contacts: {
        label: string;
        startPerf?: number;
        endPerf?: number;
    }[];
}
/**
 * Validates a sequence and expands it into segments. Geometry that depends on
 * where things are at run time is computed by each segment's `prepare`.
 */
export declare const planSequence: (host: SequenceHost, params: RunSequenceParams) => Segment[];
/**
 * Runs planned segments on sequence time. Each segment is one run of the
 * channel engine (head, pose, pinch, hand and resting hand); its end state is
 * shown for one frame before the next begins (except inside a press, where
 * the contact time matters), and the frame's leftover time carries over.
 */
export declare class SequenceRunner {
    private readonly host;
    private readonly params;
    private readonly segments;
    private readonly deadlinePerf;
    private readonly ctx;
    private index;
    private run;
    private clock;
    private segmentStart;
    private carryS;
    private stall;
    private ending;
    private finished;
    private readonly events;
    private readonly steps;
    private seenPressed;
    private seenCancels;
    private seenGestures;
    private openPress;
    private idle;
    private micro;
    constructor(host: SequenceHost, params: RunSequenceParams, segments: Segment[], deadlinePerf: number);
    get done(): boolean;
    /** Called on the first frame: lowers the other hand and starts step 0. */
    start(): void;
    /** Advances by `deltaMs`; returns leftover ms when finished, else -1. */
    tick(deltaMs: number): number;
    /** Records the select edges and microgestures the app saw on the last frame. */
    private observeEdges;
    private advanceSegment;
    private closeStep;
    /** The channels a segment runs, in the order they apply each frame. */
    private channelsFor;
    /** How far a segment's walk has gone at `t` (0 to 1). */
    private walkProgress;
    /** How far a segment's path has gone at `t` (0 to 1, eased). */
    private pathProgress;
    /**
     * The head: carried by the walk, then turned toward the work (from
     * `headStart` over `headEnd` seconds) and leaned with the reach, plus a
     * slight, slow sway.
     */
    private applyHead;
    /** Pinch: an optional pre-shape (open to a grip aperture), then the pinch itself. */
    private applyPinch;
    /** The hand along the path (carried by any walk first), the wrist turning alongside. */
    private applyPlacement;
    /**
     * The resting hand: lowered to the hip over the first step (its pose fading
     * to a loose curl), carried by walks, swaying slightly once it is there.
     */
    private applyIdleHand;
    /**
     * Wall-clock contact: the fingertip within 2 cm of the pressed surface,
     * followed into the next step when the pull-back is its lift-off.
     */
    private measureContact;
    private finish;
    /**
     * Stops now (cancel, release, watchdog, session end): the current channels
     * stop where they are; the pinch is left as it is.
     */
    abort(reason: string): SequenceResult;
    result(): SequenceResult;
    /**
     * The planned segments with estimated durations (dry run and time budget),
     * from the current state. Prepares every segment against a scratch copy of
     * the hand's pin, then puts the hand and head back.
     */
    static describe(host: SequenceHost, params: RunSequenceParams, segments: Segment[], warnings: string[]): SequencePlan;
}
/** @internal */
export declare const _testing: {
    ArcPath: typeof ArcPath;
    autoMoveSeconds: (pathLength: number, turnDeg: number, poseChange: boolean) => number;
    lookRotation: (from: vec3, to: vec3, out: quat) => quat;
};
export {};
//# sourceMappingURL=sequence.d.ts.map