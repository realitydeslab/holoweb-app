/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { HandPoseAngles } from './builder.js';
import type { HandPose } from '../../XRHandInput.js';
/**
 * Base hand poses built on the captured relaxed skeleton, so they share its
 * finger bone lengths (metacarpal to tip), joint radii, wrist and grip
 * placement and can be blended finger by finger. Only `thumb.shift` moves the
 * thumb base away from its rest position.
 * Angles are in degrees (see HandPoseAngles); each pose was tuned by rendering
 * it on the WebXR generic-hand mesh and grading it against a written brief.
 */
export declare const handPoseAngles: Record<string, HandPoseAngles>;
export declare const libraryHandPoses: Record<string, HandPose>;
/**
 * Where the thumb goes during microgestures, on the `microgesture` pose. Tap
 * and the side swipes touch the side of the index finger's middle bone and
 * slide toward its tip or knuckle; the forward and backward swipes touch a
 * little behind (or in front) and slide around the bone, over its back or
 * toward the palm. Only the thumb of these poses is used; each was solved to
 * keep the thumb tip on the finger's surface.
 */
export type MicrogestureThumb = 'touch' | 'tip-mid' | 'tip' | 'knuckle-mid' | 'knuckle' | 'forward-start' | 'forward-mid' | 'forward' | 'backward-start' | 'backward-mid' | 'backward';
export declare const microgestureThumbPoses: Record<MicrogestureThumb, HandPose>;
//# sourceMappingURL=library.d.ts.map