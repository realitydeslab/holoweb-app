/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import type { XRSession } from '../session/XRSession.js';
import type { XRSpace } from './XRSpace.js';
export declare const recordSpaceSession: (space: XRSpace, session: XRSession) => void;
/**
 * The session a space belongs to, or undefined when IWER can't tell, such as
 * for input sources' spaces, which are shared by all sessions.
 */
export declare const getSpaceSession: (space: XRSpace) => XRSession | undefined;
//# sourceMappingURL=spaceSessions.d.ts.map