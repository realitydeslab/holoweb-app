/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { XRRigidTransform } from '../primitives/XRRigidTransform.js';
import { XRSession } from '../session/XRSession.js';
import { XRView } from '../views/XRView.js';
export type XRTextureType = 'texture' | 'texture-array';
export declare class XRWebGLDepthInformation {
    readonly texture: WebGLTexture;
    readonly depthNear: number;
    readonly depthFar: number;
    readonly width: number;
    readonly height: number;
    readonly normDepthBufferFromNormView: XRRigidTransform;
    readonly rawValueToMeters: number;
    readonly textureType: XRTextureType;
    readonly imageIndex: number | null;
    readonly isValid: boolean;
    constructor(texture: WebGLTexture, width: number, height: number, normDepthBufferFromNormView: XRRigidTransform, rawValueToMeters: number, depthNear: number, depthFar: number, textureType: XRTextureType, imageIndex: number | null);
}
export declare class XRWebGLBinding {
    private _session;
    constructor(session: XRSession, _context: WebGL2RenderingContext);
    getDepthInformation(view: XRView): XRWebGLDepthInformation | null;
}
//# sourceMappingURL=XRWebGLBinding.d.ts.map