/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { P_ACTION_PLAYER } from '../private.js';
import { XRInputSource } from '../input/XRInputSource.js';
import { XRReferenceSpace } from '../spaces/XRReferenceSpace.js';
import { quat, vec3 } from 'gl-matrix';
import { InputSchema } from './ActionRecorder.js';
import { XREye } from '../views/XRView.js';
import type { XRFrame } from '../frameloop/XRFrame.js';
import type { XRSession } from '../session/XRSession.js';
import { XRSpace } from '../spaces/XRSpace.js';
export interface CompressedRecording {
    schema: {
        0: number;
        1: InputSchema;
    }[];
    frames: any[];
}
type ProcessedInputData = {
    targetRayTransform: number[];
    gripTransform?: number[];
    handTransforms?: any[];
    buttons?: {
        0: 0 | 1;
        1: 0 | 1;
        2: number;
    }[];
    axes?: number[];
};
/**
 * Context the player needs to dispatch XRInputSourceEvents
 * (selectstart/select/selectend and the squeeze variants) on edges detected
 * during playback. It mirrors XRTrackedInput.onFrameStart's dispatch, which
 * targets the session and stamps each event with the current XRFrame. The
 * player only emits events when this context has been attached (via the
 * constructor option or setEventContext); otherwise edge detection is skipped
 * and playback behaves exactly as before.
 */
export interface ActionPlayerEventContext {
    session: XRSession;
    /** Returns the XRFrame to stamp on dispatched events, or null to skip. */
    getFrame: () => XRFrame | null | undefined;
    /**
     * Called before playback jumps without traversing intervening button state,
     * allowing a host to terminate actions that were active before the jump.
     */
    onDiscontinuity?: () => void;
}
export interface ActionPlayerOptions {
    /**
     * When true, playback restarts from the beginning instead of stopping once
     * the final frame is reached. Defaults to false.
     */
    loop?: boolean;
    /**
     * Multiplier applied to the per-frame wall-clock delta in playFrame(). 1 is
     * realtime (default); 2 plays back twice as fast, 0.5 half speed.
     */
    playbackRate?: number;
    /**
     * Advanced event adapter for hosts that dispatch playback input events.
     * A native override temporarily replaces this value while wired and restores
     * the previous value when unwired.
     */
    eventContext?: ActionPlayerEventContext;
}
export declare class ActionPlayer {
    [P_ACTION_PLAYER]: {
        refSpace: XRReferenceSpace;
        inputSources: Map<number, {
            active: boolean;
            source: XRInputSource;
        }>;
        inputSchemas: Map<number, InputSchema>;
        frames: any[];
        recordedFramePointer: number;
        startingTimeStamp: DOMHighResTimeStamp;
        endingTimeStamp: DOMHighResTimeStamp;
        playbackTime: DOMHighResTimeStamp;
        actualTimeStamp?: DOMHighResTimeStamp;
        playing: boolean;
        /** Whether native frame cadence should advance wall-clock playback. */
        autoAdvance: boolean;
        /**
         * Whether native mode should keep presenting the most recently sampled
         * manual frame after non-looping playback reaches its end.
         */
        manualFrameActive: boolean;
        viewerSpace: XRReferenceSpace;
        viewSpaces: {
            [key in XREye]: XRSpace;
        };
        vec3: vec3;
        quat: quat;
        f1p: vec3;
        f1q: quat;
        f2p: vec3;
        f2q: quat;
        lastFrameInputs: Map<number, ProcessedInputData>;
        nextFrameInputs: Map<number, ProcessedInputData>;
        loop: boolean;
        playbackRate: number;
        eventContext?: ActionPlayerEventContext;
        lastEventFramePointer: number;
        startedActions: Map<string, {
            index: number;
            trigger: 'select' | 'squeeze';
        }>;
        cancelPending: boolean;
    };
    constructor(refSpace: XRReferenceSpace, recording: {
        schema: {
            0: number;
            1: InputSchema;
        }[];
        frames: any[];
    }, ipd: number, options?: ActionPlayerOptions);
    play(): void;
    stop(): void;
    get playing(): boolean;
    get viewerSpace(): XRReferenceSpace;
    get viewSpaces(): {
        none: XRSpace;
        left: XRSpace;
        right: XRSpace;
    };
    get inputSources(): XRInputSource[];
    get loop(): boolean;
    set loop(value: boolean);
    get playbackRate(): number;
    set playbackRate(value: number);
    /**
     * Attach (or clear) the event context used to dispatch select/squeeze events
     * during playback. Passing undefined disables event dispatch.
     */
    setEventContext(context?: ActionPlayerEventContext): void;
    /**
     * Total length of the recording in milliseconds (last frame timestamp minus
     * first). 0 for a single-frame recording.
     */
    get duration(): number;
    /**
     * Current playback position in milliseconds, relative to the start of the
     * recording (0 at the first frame).
     */
    get currentTime(): number;
    /**
     * Jump playback to an absolute position, expressed in milliseconds relative to
     * the start of the recording. The time is clamped to [0, duration]. The frame
     * pointer is resolved with a binary search over the frames (sorted ascending
     * by timestamp at frame[0]), so backward seeks work correctly. Does not render
     * a frame on its own; the next playFrame()/stepFrames() call samples the new
     * position. The wall-clock anchor is reset so a subsequent playFrame() doesn't
     * fast-forward across the jump.
     */
    seek(timeMs: number): void;
    /**
     * Binary search for the index of the last frame whose timestamp is <= the
     * given absolute time. Returns 0 when the time precedes the first frame.
     */
    private findFramePointer;
    /**
     * Advance playback by exactly n recorded frames (default 1), deterministically
     * and independent of wall-clock time, for headless/agent driving. Each step
     * samples the recording at a frame boundary (alpha == 0, no interpolation) and
     * dispatches any select/squeeze edges between consecutive frames. When loop is
     * enabled, stepping past the final frame wraps to the start; otherwise it
     * clamps to the final frame and stops playback. Sets playing to true on entry
     * so the surrounding pose getters report this player's spaces.
     */
    stepFrames(n?: number): void;
    playFrame(): void;
    /**
     * Sample the recording at the current frame pointer, applying poses, hands,
     * gamepad state, and active flags, and dispatch any select/squeeze edges
     * crossed since the previous applied frame. `alpha` is the interpolation
     * factor toward the next frame (0 snaps exactly to the pointer's frame, as the
     * deterministic stepFrames path uses). When there is no next frame the pointer
     * frame is used for both ends.
     */
    private applyFrameAtPointer;
    /**
     * Detect rising/falling edges of select/squeeze-triggering buttons between the
     * previously applied frame and the one at the current pointer, then dispatch
     * the corresponding XRInputSourceEvents on the session — mirroring
     * XRTrackedInput.onFrameStart's edge logic (lastValue 0 -> >0 fires
     * <trigger>+<trigger>start; >0 -> 0 fires <trigger>end). All frame boundaries
     * skipped since the last applied frame are scanned so no edge is missed when
     * the pointer advances by more than one frame. No-ops unless an event context
     * is attached and yields a frame. The recording format does not persist
     * per-button eventTrigger, so the xr-standard convention is used: button 0 ->
     * 'select', button 1 -> 'squeeze'.
     */
    private dispatchSelectSqueezeEdges;
    /**
     * Compare the recorded button values of two adjacent frames and dispatch the
     * select/squeeze edges between them on the given session/frame.
     */
    private dispatchEdgesBetweenFrames;
    /** Mark a jump in playback: started actions are cancelled on the next dispatch. */
    private markDiscontinuity;
    /**
     * Ends every started action without completing it (`<trigger>end` alone),
     * or forgets them when there is no frame to deliver on.
     */
    private cancelStartedActions;
    /**
     * Map a recorded button index to its event trigger: for xr-standard mappings
     * button 0 -> 'select' and button 1 -> 'squeeze' (a hand's button 1 is an
     * empty slot, and its gesture buttons, 4 to 9, have no trigger); for hands
     * recorded before the hand gamepad had a mapping, button 0, the pinch,
     * -> 'select'. Other buttons have no trigger.
     */
    private eventTriggerForButton;
    updateInputSource(inputSource: XRInputSource, schema: InputSchema, lastInputData: ProcessedInputData, nextInputData: ProcessedInputData, alpha: number): void;
    updateXRSpaceFromMergedFrames(space: XRSpace, lastTransform: number[], nextTransform: number[], alpha: number): void;
    processRawInputData(inputDataRaw: any[]): {
        index: any;
        inputData: ProcessedInputData;
    };
}
export declare const mergeTransform: (f1: number[], f2: number[], alpha: number, position: vec3, quaternion: quat) => void;
export {};
//# sourceMappingURL=ActionPlayer.d.ts.map