/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import type { XRFrame } from '../frameloop/XRFrame.js';
import type { WebGPUCommandEncoder, WebGPUDevice, WebGPUTexture } from '../types/webgpu.js';
export type GPULayerTextureSet = {
    color: WebGPUTexture;
    depthStencil: WebGPUTexture | null;
    motionVector: WebGPUTexture | null;
};
export type GPULayerTextureDescriptors = {
    color: GPUTextureDescriptor;
    depthStencil: GPUTextureDescriptor | null;
    motionVector: GPUTextureDescriptor | null;
};
/**
 * The textures of a WebGPU-backed layer, following the WebGPU binding's
 * texture lifecycle. The first subimage request in a frame gets new, cleared
 * "current" textures, which every subimage of the layer shares for that frame.
 * When the frame ends they're released: IWER copies them into textures of its
 * own for the compositor and destroys them, so retained subimages only see
 * destroyed textures and the compositor keeps showing the last released
 * content.
 */
export declare class GPULayerTextures {
    readonly device: WebGPUDevice;
    readonly descriptors: GPULayerTextureDescriptors;
    readonly releaseDepth: boolean;
    readonly compositorViewDimension: GPUTextureViewDimension;
    current: (GPULayerTextureSet & {
        frame: XRFrame;
    }) | null;
    released: GPULayerTextureSet | null;
    releasedFrame: XRFrame | null;
    destroyed: boolean;
    private compositorTextures;
    private rightCubeFaces;
    private synthesis;
    private kept;
    private drawn;
    releasedMotion: boolean;
    constructor(device: WebGPUDevice, descriptors: GPULayerTextureDescriptors, releaseDepth?: boolean, compositorViewDimension?: GPUTextureViewDimension);
    private get splitsCube();
    /** The compositor's texture with an eye's six cube faces, from layer 0. */
    cubeFaces(eyeIndex: number): WebGPUTexture;
    acquire(frame: XRFrame): GPULayerTextureSet & {
        frame: XRFrame;
    };
    /**
     * Hands the frame's current textures to the compositor by copying them into
     * its own textures. Returns false if the layer wasn't drawn in this frame.
     */
    release(frame: XRFrame, encoder: WebGPUCommandEncoder): boolean;
    /**
     * Where IWER draws the frames it synthesizes from the released textures with
     * space warp: a color texture laid out like the layer's, and a depth buffer.
     */
    synthesisTargets(): {
        color: WebGPUTexture;
        depth: WebGPUTexture;
    };
    expire(): void;
    /**
     * The app may destroy a current texture to end its write access, but the
     * binding says that leaves the layer's image alone. IWER's current textures
     * are that image, so it copies what was drawn for the compositor first.
     */
    private watchViews;
    private keepOnDestroy;
    private copy;
    destroy(): void;
    private createCompositorTextures;
}
//# sourceMappingURL=GPULayerTextures.d.ts.map