/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { GamepadConfig } from '../gamepad/Gamepad.js';
import { GlobalSpace } from '../spaces/XRSpace.js';
import { P_CONTROLLER } from '../private.js';
import { XRHandedness } from '../input/XRInputSource.js';
import { XRTrackedInput } from './XRTrackedInput.js';
import { mat4 } from 'gl-matrix';
export interface XRControllerConfig {
    profileId: string;
    fallbackProfileIds: string[];
    layout: {
        [handedness in XRHandedness]?: {
            gamepad: GamepadConfig;
            gripOffsetMatrix?: mat4;
            numHapticActuators: number;
        };
    };
}
export declare class XRController extends XRTrackedInput {
    [P_CONTROLLER]: {
        profileId: string;
        gamepadConfig: GamepadConfig;
    };
    constructor(controllerConfig: XRControllerConfig, handedness: XRHandedness, globalSpace: GlobalSpace);
    get gamepadConfig(): GamepadConfig;
    get profileId(): string;
    updateButtonValue(id: string, value: number): void;
    /**
     * Set button value immediately (bypasses pending mechanism).
     * Use this for programmatic control where value should be readable
     * immediately. Releasing a pressed button this way cancels its action
     * (`selectend`/`squeezeend` without `select`/`squeeze`).
     */
    setButtonValueImmediate(id: string, value: number): void;
    updateButtonTouch(id: string, touched: boolean): void;
    updateAxis(id: string, type: 'x-axis' | 'y-axis', value: number): void;
    updateAxes(id: string, x: number, y: number): void;
    /**
     * Whether a button is pressed, including a value written this frame that
     * the next frame will apply (matching getButtonValue).
     */
    getButtonPressed(id: string): boolean;
    /**
     * Get the current value of a button by id
     */
    getButtonValue(id: string): number;
    /**
     * Get the touched state of a button by id
     */
    getButtonTouched(id: string): boolean;
    /**
     * Get the current axes values for a given id (e.g., 'thumbstick')
     */
    getAxes(id?: string): {
        x: number;
        y: number;
    };
}
//# sourceMappingURL=XRController.d.ts.map