/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import type { mat4 } from 'gl-matrix';
import type { GPULayerTextures } from './GPULayerTextures.js';
export type SpaceWarpView = {
    arrayLayer: number;
    clipFromSource: mat4;
    colorScale: number;
};
/**
 * Synthesizes a frame from a projection layer's last released textures, as
 * space warp does: every motion vector texel moves `extrapolation` times its
 * motion vector, and depth reprojects it into each view's current pose. The
 * frame is drawn into the layer's synthesis targets, laid out like its color
 * texture.
 */
export declare const synthesizeFrame: (textures: GPULayerTextures, views: SpaceWarpView[], extrapolation: number) => void;
//# sourceMappingURL=GPUSpaceWarp.d.ts.map