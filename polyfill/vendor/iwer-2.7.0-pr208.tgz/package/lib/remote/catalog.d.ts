/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
/**
 * JSON Schema (draft 2020-12 subset: type, properties, required,
 * additionalProperties, enum, anyOf, items, prefixItems, minItems, maxItems,
 * minimum, maximum, exclusiveMinimum) for the parameters of every
 * `device.remote` method. Kept free of imports so tool hosts (the extension
 * bridge, IWSDK) can read it without loading IWER: import
 * `iwer/lib/remote/catalog.js`. No `$ref` or `const`; unions use `anyOf`.
 *
 * Objects that reject unknown keys have `additionalProperties: false`; the
 * others (methods older than catalog version 3) accept and ignore them.
 */
type Schema = Record<string, unknown>;
/** Parameter schemas for every remote method, by method name. */
export declare const REMOTE_METHOD_SCHEMAS: Readonly<Record<string, Schema>>;
export {};
//# sourceMappingURL=catalog.d.ts.map