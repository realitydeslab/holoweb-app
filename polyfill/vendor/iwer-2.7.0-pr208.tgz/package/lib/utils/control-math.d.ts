/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import type { Vec3, Quat, EulerRotation } from '../types/state.js';
/**
 * Convert a Vector3-like object to a plain Vec3 object
 */
export declare function vec3ToObj(v: {
    x: number;
    y: number;
    z: number;
}): Vec3;
/**
 * Convert a Quaternion-like object to a plain Quat object
 */
export declare function quatToObj(q: {
    x: number;
    y: number;
    z: number;
    w: number;
}): Quat;
/**
 * Convert quaternion to euler angles (in degrees)
 * Uses YXZ order (yaw-pitch-roll) which is standard for XR:
 * - Yaw: rotation around Y axis (turning left/right)
 * - Pitch: rotation around X axis (looking up/down)
 * - Roll: rotation around Z axis (tilting head)
 */
export declare function quatToEuler(q: Quat): EulerRotation;
/**
 * Convert euler angles (in degrees) to quaternion
 * Uses YXZ order (yaw-pitch-roll) which is standard for XR:
 * - Yaw: rotation around Y axis (turning left/right)
 * - Pitch: rotation around X axis (looking up/down)
 * - Roll: rotation around Z axis (tilting head)
 * Missing angles default to 0.
 */
export declare function eulerToQuat(euler: Partial<EulerRotation>): Quat;
/**
 * Calculate normalized direction vector from one point to another
 * Returns default forward direction (0, 0, -1) if points are coincident
 */
export declare function directionTo(from: Vec3, to: Vec3): Vec3;
/**
 * Calculate gimbal-style look rotation (yaw + pitch only, roll = 0)
 * This keeps the camera/headset level while looking at a target.
 * @param direction - The direction to look towards
 * @returns Quaternion with only yaw and pitch, no roll
 */
export declare function lookRotationGimbal(direction: Vec3): Quat;
/**
 * Calculate quaternion that looks from origin towards a direction
 * @param direction - The direction to look towards (will be normalized)
 * @param up - The up vector (default: world up Y-axis)
 */
export declare function lookRotation(direction: Vec3, up?: Vec3): Quat;
/**
 * Wait for a condition to become true, checking each animation frame
 */
export declare function waitForCondition(condition: () => boolean, timeoutMs?: number): Promise<void>;
//# sourceMappingURL=control-math.d.ts.map