/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { quat, vec3 } from 'gl-matrix';
import { P_ACTION_RECORDER } from '../private.js';
export interface InputFrame {
    index: number;
    targetRayTransform: {
        position: vec3;
        quaternion: quat;
    };
    gripTransform?: {
        position: vec3;
        quaternion: quat;
    };
    hand?: {
        [joint in XRHandJoint]: {
            position: number[];
            quaternion: number[];
            radius: number;
        };
    };
    gamepad?: {
        buttons: (number[] | null)[];
        axes: (number | null)[];
    };
}
export interface InputSchema {
    handedness: XRHandedness;
    targetRayMode: XRTargetRayMode;
    profiles: string[];
    hasGrip: boolean;
    hasHand: boolean;
    jointSequence?: XRHandJoint[];
    hasGamepad: boolean;
    mapping?: GamepadMappingType;
    numButtons?: number;
    numAxes?: number;
}
export interface ActionFrame {
    timeStamp: DOMHighResTimeStamp;
    position: vec3;
    quaternion: quat;
    inputFrames: InputFrame[];
}
/**
 * Policy applied when a recording cap (maxFrames / maxDurationMs) is reached.
 * - 'stop' (default): stop recording new frames; already-recorded frames are
 *   kept intact.
 * - 'drop': drop the oldest recorded frame(s) to make room for new ones,
 *   keeping a sliding window of the most recent frames.
 */
export type RecordingCapPolicy = 'stop' | 'drop';
export interface ActionRecorderOptions {
    /**
     * Maximum number of frames to keep. Omit (or use a non-positive value) for
     * unlimited recording (default).
     */
    maxFrames?: number;
    /**
     * Maximum recording duration in milliseconds, measured from the first
     * recorded frame's timestamp. Omit (or use a non-positive value) for
     * unlimited recording (default).
     */
    maxDurationMs?: number;
    /**
     * Behavior when a cap is reached. Defaults to 'stop'.
     */
    capPolicy?: RecordingCapPolicy;
}
export declare class ActionRecorder {
    [P_ACTION_RECORDER]: {
        session: XRSession;
        refSpace: XRReferenceSpace;
        inputMap: Map<XRInputSource, number>;
        schemaMap: Map<number, InputSchema>;
        compressedFrames: any[];
        jointRadii: Float32Array;
        jointTransforms: Float32Array;
        maxFrames: number;
        maxDurationMs: number;
        capPolicy: RecordingCapPolicy;
        firstTimeStamp: number | null;
        lastTimeStamp: number | null;
    };
    constructor(session: XRSession, refSpace: XRReferenceSpace, options?: ActionRecorderOptions);
    /** Number of frames currently recorded. */
    get frameCount(): number;
    /**
     * Duration of the recording in milliseconds, measured from the first to the
     * most recently recorded frame. Returns 0 when fewer than two frames have
     * been recorded.
     */
    get durationMs(): number;
    recordFrame(frame: XRFrame): void;
    compressActionFrame(af: ActionFrame): any[];
    /**
     * Build the serialized recording object (the same shape ActionPlayer's
     * constructor consumes): the schema entries paired with the compressed frame
     * rows. Returned by reference, so callers that mutate it affect the recorder's
     * live buffers; clone if you need a detached snapshot.
     */
    getRecording(): {
        schema: [number, InputSchema][];
        frames: any[];
    };
    /** Serialize the current recording to a JSON string. */
    toJSON(): string;
    log(): void;
}
//# sourceMappingURL=ActionRecorder.d.ts.map