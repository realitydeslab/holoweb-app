/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { P_SPACE_LAYER } from '../private.js';
import { XRCompositionLayer, type XRCompositionLayerInit } from './XRProjectionLayer.js';
import type { XRLayerEventHandler } from '../events/XRLayerEvent.js';
import { XRRigidTransform } from '../primitives/XRRigidTransform.js';
import { XRSpace } from '../spaces/XRSpace.js';
import type { XRSession } from '../session/XRSession.js';
declare const checkSpace: (session: XRSession, space: XRSpace, environment: boolean) => XRSpace;
type SpaceLayerState = {
    space: XRSpace;
    onredraw: XRLayerEventHandler | null;
};
/**
 * Shared by quad, cylinder, equirect and cube layers: a space and a redraw
 * event handler.
 */
declare abstract class XRSpaceLayer<State extends SpaceLayerState> extends XRCompositionLayer {
    [P_SPACE_LAYER]: State;
    protected abstract readonly environment: boolean;
    constructor(session: XRSession, init: XRCompositionLayerInit, state: State);
    get space(): XRSpace;
    set space(space: XRSpace);
    get onredraw(): XRLayerEventHandler | null;
    set onredraw(callback: XRLayerEventHandler | null);
}
export { checkSpace as checkLayerSpace };
type QuadState = SpaceLayerState & {
    transform: XRRigidTransform;
    width: number;
    height: number;
};
export declare class XRQuadLayer extends XRSpaceLayer<QuadState> {
    protected readonly environment = false;
    get transform(): XRRigidTransform;
    set transform(transform: XRRigidTransform);
    get width(): number;
    set width(width: number);
    get height(): number;
    set height(height: number);
}
type CylinderState = SpaceLayerState & {
    transform: XRRigidTransform;
    radius: number;
    centralAngle: number;
    aspectRatio: number;
};
export declare class XRCylinderLayer extends XRSpaceLayer<CylinderState> {
    protected readonly environment = false;
    get transform(): XRRigidTransform;
    set transform(transform: XRRigidTransform);
    get radius(): number;
    set radius(radius: number);
    get centralAngle(): number;
    set centralAngle(centralAngle: number);
    get aspectRatio(): number;
    set aspectRatio(aspectRatio: number);
}
type EquirectState = SpaceLayerState & {
    transform: XRRigidTransform;
    radius: number;
    centralHorizontalAngle: number;
    upperVerticalAngle: number;
    lowerVerticalAngle: number;
};
export declare class XREquirectLayer extends XRSpaceLayer<EquirectState> {
    protected readonly environment = true;
    get transform(): XRRigidTransform;
    set transform(transform: XRRigidTransform);
    get radius(): number;
    set radius(radius: number);
    get centralHorizontalAngle(): number;
    set centralHorizontalAngle(angle: number);
    get upperVerticalAngle(): number;
    set upperVerticalAngle(angle: number);
    get lowerVerticalAngle(): number;
    set lowerVerticalAngle(angle: number);
}
type CubeState = SpaceLayerState & {
    orientation: DOMPointReadOnly;
};
export declare class XRCubeLayer extends XRSpaceLayer<CubeState> {
    protected readonly environment = true;
    get orientation(): DOMPointReadOnly;
    set orientation(orientation: DOMPointReadOnly);
}
//# sourceMappingURL=XRSpaceLayers.d.ts.map