/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
/** Positive angular extents, in radians, from the optical axis. */
export interface XRFieldOfView {
    angleLeft: number;
    angleRight: number;
    angleUp: number;
    angleDown: number;
}
/** Per-eye visible field used to obscure content outside a target headset FOV. */
export interface XRVisibilityMask {
    left: XRFieldOfView;
    right: XRFieldOfView;
}
/** Pixel bounds of the visible opening inside one emulated eye viewport. */
export interface XRVisibilityMaskBounds {
    x: number;
    y: number;
    width: number;
    height: number;
}
/**
 * Convert angular target bounds into a rectangular opening in an IWER preview.
 *
 * The preview projection is symmetric and described by `previewFovY`. Target
 * bounds may be asymmetric, so the resulting opening need not be centered.
 */
export declare function calculateVisibilityMaskBounds(fieldOfView: XRFieldOfView, previewFovY: number, viewportWidth: number, viewportHeight: number): XRVisibilityMaskBounds;
//# sourceMappingURL=XRVisibilityMask.d.ts.map