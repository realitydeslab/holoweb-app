/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import type { XRHandInput } from '../device/XRHandInput.js';
import type { Channel } from './channels.js';
/**
 * Thumb microgestures, as Quest reports them on the hand gamepad: swipes
 * along the side of the curled index finger (left / right, the user's left
 * and right), over it (forward) or back toward the palm (backward), and a
 * tap on its side.
 */
export declare const MICROGESTURES: readonly ["swipe-left", "swipe-right", "swipe-forward", "swipe-backward", "tap"];
export type Microgesture = (typeof MICROGESTURES)[number];
export declare const isMicrogesture: (value: unknown) => value is Microgesture;
/** The hand gamepad button of each microgesture (5 to 9, as on Quest). */
export declare const microgestureButton: (gesture: Microgesture) => number;
/** The hand pose microgestures start from and return to. */
export declare const MICROGESTURE_POSE = "microgesture";
/** Seconds a hand not in the microgesture pose takes to get into it. */
export declare const MICROGESTURE_READY_S = 0.25;
/**
 * Whether a hand can start a microgesture at once: in the microgesture pose
 * (no finger blends, no pose change in progress) with `pinch` (the pinch last
 * written) open.
 */
export declare const readyForMicrogesture: (hand: XRHandInput, pinch: number) => boolean;
/** Seconds a microgesture takes, from the thumb leaving rest to its return. */
export declare const microgestureSeconds: (gesture: Microgesture) => number;
/**
 * Plays one microgesture on a hand in the microgesture pose: the thumb
 * touches the index finger, slides (or taps) and lifts back to rest. Like
 * Quest, the gesture registers at the end of the motion, as the thumb lifts:
 * its button is pressed for 35 ms, and always for at least one frame.
 */
export declare class MicrogesturePlayer {
    private readonly hand;
    readonly gesture: Microgesture;
    /** Seconds the motion takes. */
    readonly duration: number;
    /** Seconds from the start at which the button is pressed. */
    readonly registerAt: number;
    /** The hand gamepad button it presses. */
    readonly button: number;
    private readonly rest;
    private readonly slide;
    private readonly slideEnd;
    private pressed;
    private released;
    private pressUnseen;
    private holding;
    constructor(hand: XRHandInput, gesture: Microgesture);
    /** Seconds from the start at which the button was pressed, or null. */
    get pressedAt(): number | null;
    /**
     * True when finish() kept the button down because it was pressed on the
     * same frame: call finish() again on the next frame.
     */
    get releasePending(): boolean;
    /** Shows the thumb `elapsed` seconds in. */
    private showThumb;
    private writeButton;
    /**
     * Shows the thumb `elapsed` seconds into the gesture and writes the button.
     * Call once per frame; returns 'press' on the frame the gesture registers.
     */
    apply(elapsed: number): 'press' | null;
    /**
     * Ends the gesture: the thumb back at rest and the button up. A button
     * pressed on this very frame stays down for it (`releasePending`); call
     * finish() again on the next frame to release it.
     */
    finish(): void;
    /** Stops the gesture now: the thumb at rest, the button up. */
    cancel(): void;
    /**
     * The gesture as a `thumb` channel of `device`, starting `delayMs` into its
     * run. Its last frame calls finish(); stopping it early cancels.
     */
    channel(device: string, delayMs?: number): Channel;
}
//# sourceMappingURL=microgesture.d.ts.map