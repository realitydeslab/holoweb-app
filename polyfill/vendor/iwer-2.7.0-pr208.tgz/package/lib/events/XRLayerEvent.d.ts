/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import type { XRLayer } from '../layers/XRWebGLLayer.js';
interface XRLayerEventInit extends EventInit {
    layer: XRLayer;
}
export declare class XRLayerEvent extends Event {
    readonly layer: XRLayer;
    constructor(type: string, eventInitDict: XRLayerEventInit);
}
export interface XRLayerEventHandler {
    (evt: XRLayerEvent): any;
}
export {};
//# sourceMappingURL=XRLayerEvent.d.ts.map