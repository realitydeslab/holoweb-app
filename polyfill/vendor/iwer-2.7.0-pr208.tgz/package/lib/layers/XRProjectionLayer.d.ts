/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { P_COMPOSITION_LAYER, P_PROJECTION_LAYER } from '../private.js';
import { XRLayer } from './XRWebGLLayer.js';
import { XRRigidTransform } from '../primitives/XRRigidTransform.js';
import type { GPULayerTextures } from './GPULayerTextures.js';
import type { GPUMediaTextures } from './GPUMediaTextures.js';
import type { XRSession } from '../session/XRSession.js';
export type XRLayerLayout = 'default' | 'mono' | 'stereo' | 'stereo-left-right' | 'stereo-top-bottom';
export type XRLayerQuality = 'default' | 'text-optimized' | 'graphics-optimized';
export type XRCompositionLayerInit = {
    layout: XRLayerLayout;
    isStatic: boolean;
    mipLevels: number;
    textures: GPULayerTextures | GPUMediaTextures;
};
/**
 * Base class of the layers created by XRGPUBinding. Each is backed by WebGPU
 * textures on the binding's device.
 */
export declare class XRCompositionLayer extends XRLayer {
    [P_COMPOSITION_LAYER]: {
        session: XRSession;
        destroyed: boolean;
        blendTextureSourceAlpha: boolean;
        forceMonoPresentation: boolean;
        opacity: number;
        quality: XRLayerQuality;
        layout: XRLayerLayout;
        isStatic: boolean;
        mipLevels: number;
        needsRedraw: boolean;
        textures: GPULayerTextures | GPUMediaTextures;
    };
    constructor(session: XRSession, init: XRCompositionLayerInit);
    get layout(): XRLayerLayout;
    get isStatic(): boolean;
    get needsRedraw(): boolean;
    get mipLevels(): number;
    get blendTextureSourceAlpha(): boolean;
    set blendTextureSourceAlpha(value: boolean);
    get forceMonoPresentation(): boolean;
    set forceMonoPresentation(value: boolean);
    get opacity(): number;
    set opacity(value: number);
    get quality(): XRLayerQuality;
    set quality(value: XRLayerQuality);
    destroy(): void;
}
/**
 * A projection layer backed by a WebGPU texture array with one array layer per
 * view, created by XRGPUBinding.createProjectionLayer.
 */
export declare class XRProjectionLayer extends XRCompositionLayer {
    [P_COMPOSITION_LAYER]: XRCompositionLayer[typeof P_COMPOSITION_LAYER] & {
        textures: GPULayerTextures;
    };
    [P_PROJECTION_LAYER]: {
        ignoreDepthValues: boolean;
        fixedFoveation: number;
        frameFixedFoveation: number;
        frameViewportScales: number[];
        viewportScales: number[];
        deltaPose: XRRigidTransform | null;
    };
    constructor(session: XRSession, textures: GPULayerTextures, ignoreDepthValues: boolean);
    get textureWidth(): number;
    get textureHeight(): number;
    get textureArrayLength(): number;
    get ignoreDepthValues(): boolean;
    get fixedFoveation(): number | null;
    set fixedFoveation(value: number | null);
    get deltaPose(): XRRigidTransform | null;
    set deltaPose(value: XRRigidTransform | null);
}
//# sourceMappingURL=XRProjectionLayer.d.ts.map