/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { XRSpace } from '../spaces/XRSpace.js';
import { XRTrackedInput } from './XRTrackedInput.js';
export declare const GAZE_TRACKING_FEATURES: readonly ["gaze-tracking", "eye-tracking"];
export type GazeTrackingFeature = (typeof GAZE_TRACKING_FEATURES)[number];
export declare const isGazeTrackingFeature: (feature: string) => feature is GazeTrackingFeature;
/**
 * Returns whether a feature list advertises either spelling of the gaze
 * capability. The two descriptors are compatibility aliases for one source.
 */
export declare const supportsGazeTracking: (supportedFeatures: readonly string[]) => boolean;
/**
 * A persistent, viewer-relative gaze source.
 *
 * Gaze intentionally has no gamepad and emits no select events. Applications
 * combine its target ray with select state from an independent hand or
 * controller source (the gaze-plus-pinch contract used by IWSDK).
 */
export declare class XRGazeInput extends XRTrackedInput {
    constructor(viewerSpace: XRSpace);
    updateTargetRaySpace(): void;
}
//# sourceMappingURL=XRGazeInput.d.ts.map