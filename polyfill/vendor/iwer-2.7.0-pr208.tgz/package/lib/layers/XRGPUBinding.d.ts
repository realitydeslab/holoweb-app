/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { P_DEPTH_INFO, P_GPU_BINDING, P_GPU_SUB_IMAGE, P_SUB_IMAGE } from '../private.js';
import { XREye, type XRView } from '../views/XRView.js';
import { XRCompositionLayer, XRProjectionLayer, type XRLayerLayout } from './XRProjectionLayer.js';
import { XRCubeLayer, XRCylinderLayer, XREquirectLayer, XRQuadLayer } from './XRSpaceLayers.js';
import { XRViewport } from '../views/XRViewport.js';
import { XRRigidTransform } from '../primitives/XRRigidTransform.js';
import type { XRFrame } from '../frameloop/XRFrame.js';
import type { XRSession } from '../session/XRSession.js';
import type { XRSpace } from '../spaces/XRSpace.js';
import type { WebGPUDevice, WebGPUTexture, WebGPUTextureFormat, WebGPUTextureViewDescriptor } from '../types/webgpu.js';
export interface XRGPUProjectionLayerInit {
    colorFormat: WebGPUTextureFormat;
    depthStencilFormat?: WebGPUTextureFormat;
    textureUsage?: number;
    scaleFactor?: number;
}
export interface XRGPULayerInit {
    colorFormat: WebGPUTextureFormat;
    depthStencilFormat?: WebGPUTextureFormat;
    textureUsage?: number;
    space: XRSpace;
    mipLevels?: number;
    viewPixelWidth: number;
    viewPixelHeight: number;
    layout?: XRLayerLayout;
    isStatic?: boolean;
}
export interface XRGPUQuadLayerInit extends XRGPULayerInit {
    transform?: XRRigidTransform | null;
    width?: number;
    height?: number;
}
export interface XRGPUCylinderLayerInit extends XRGPULayerInit {
    transform?: XRRigidTransform | null;
    radius?: number;
    centralAngle?: number;
    aspectRatio?: number;
}
export interface XRGPUEquirectLayerInit extends XRGPULayerInit {
    transform?: XRRigidTransform | null;
    radius?: number;
    centralHorizontalAngle?: number;
    upperVerticalAngle?: number;
    lowerVerticalAngle?: number;
}
export interface XRGPUCubeLayerInit extends XRGPULayerInit {
    orientation?: DOMPointReadOnly | null;
}
export declare const LAYOUTS: XRLayerLayout[];
export declare const toFloat: (value: number | undefined, fallback: number) => number;
export declare class XRSubImage {
    [P_SUB_IMAGE]: {
        viewport: XRViewport;
    };
    constructor(viewport: XRViewport);
    get viewport(): XRViewport;
}
export declare class XRGPUSubImage extends XRSubImage {
    [P_GPU_SUB_IMAGE]: {
        colorTexture: WebGPUTexture;
        depthStencilTexture: WebGPUTexture | null;
        motionVectorTexture: WebGPUTexture | null;
        arrayLayerIndex: number;
    };
    constructor(viewport: XRViewport, colorTexture: WebGPUTexture, depthStencilTexture: WebGPUTexture | null, motionVectorTexture: WebGPUTexture | null, arrayLayerIndex: number);
    get colorTexture(): WebGPUTexture;
    get depthStencilTexture(): WebGPUTexture | null;
    get motionVectorTexture(): WebGPUTexture | null;
    getViewDescriptor(): WebGPUTextureViewDescriptor;
}
export declare class XRGPUDepthInformation {
    [P_DEPTH_INFO]: {
        texture: WebGPUTexture;
        width: number;
        height: number;
        normDepthBufferFromNormView: XRRigidTransform;
        rawValueToMeters: number;
        arrayLayer: number;
    };
    constructor(texture: WebGPUTexture, width: number, height: number, rawValueToMeters: number, arrayLayer: number);
    get texture(): WebGPUTexture;
    get width(): number;
    get height(): number;
    get normDepthBufferFromNormView(): XRRigidTransform;
    get rawValueToMeters(): number;
    getViewDescriptor(): WebGPUTextureViewDescriptor;
}
export declare const copyTransform: (transform: XRRigidTransform | null | undefined) => XRRigidTransform;
export declare class XRGPUBinding {
    [P_GPU_BINDING]: {
        session: XRSession;
        device: WebGPUDevice;
        depthTextures: WeakMap<XRFrame, WebGPUTexture>;
    };
    constructor(session: XRSession, device: WebGPUDevice);
    get nativeProjectionScaleFactor(): number;
    get usesDepthValues(): boolean;
    getPreferredColorFormat(): WebGPUTextureFormat;
    createProjectionLayer(init: XRGPUProjectionLayerInit): XRProjectionLayer;
    createQuadLayer(init: XRGPUQuadLayerInit): XRQuadLayer;
    createCylinderLayer(init: XRGPUCylinderLayerInit): XRCylinderLayer;
    createEquirectLayer(init: XRGPUEquirectLayerInit): XREquirectLayer;
    createCubeLayer(init: XRGPUCubeLayerInit): XRCubeLayer;
    getSubImage(layer: XRCompositionLayer, frame: XRFrame, eye?: XREye): XRGPUSubImage;
    getViewSubImage(layer: XRProjectionLayer, view: XRView): XRGPUSubImage;
    private validateLayerCreation;
    private initializeLayer;
    private validateSubImage;
    getDepthInformation(view: XRView): XRGPUDepthInformation | null;
}
//# sourceMappingURL=XRGPUBinding.d.ts.map