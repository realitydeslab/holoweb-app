/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import type { GamepadButton } from './Gamepad.js';
/**
 * Press and release levels for an analog button. A released button presses
 * once its value reaches `press`; a pressed button releases once its value
 * falls to `release` or below.
 */
export interface ButtonThresholds {
    press: number;
    release: number;
}
/**
 * What a frame did to a button: pressed it, released it, cancelled a press the
 * app had seen, or nothing.
 */
export type ButtonEdge = 'press' | 'release' | 'cancel' | null;
/**
 * The input source events for an edge, in WebXR order: `<trigger>start` on
 * press, `<trigger>` then `<trigger>end` on release, and `<trigger>end` alone
 * when the action is cancelled.
 */
export declare const edgeEventTypes: (edge: ButtonEdge, trigger: "select" | "squeeze") => string[];
/** The pressed flag after `value` is applied to a button whose flag is `pressed`. */
export declare const nextPressed: (button: GamepadButton, pressed: boolean, value: number) => boolean;
/** Sets the value the button takes on the next frame (the latest write wins). */
export declare const writePendingValue: (button: GamepadButton, value: number) => void;
/**
 * Releases the button now without completing its action. If the app saw the
 * button pressed, the next frame reports a cancel (`<trigger>end` alone).
 */
export declare const cancelButton: (button: GamepadButton) => void;
/**
 * Releases the button silently, for an input source that is going away after
 * its edges were already delivered (or can no longer be delivered).
 */
export declare const resetButton: (button: GamepadButton) => void;
/**
 * Sets a value that is readable right away. A write that releases a pressed
 * button cancels it, since immediate writes are how interactions get
 * cancelled; any other write takes effect now and its edge is reported on the
 * next frame.
 */
export declare const writeImmediateValue: (button: GamepadButton, value: number) => void;
/**
 * Advances the button by one frame: applies the pending value, updates the
 * pressed flag, and reports the edge.
 */
export declare const advanceButton: (button: GamepadButton) => ButtonEdge;
//# sourceMappingURL=button-edges.d.ts.map